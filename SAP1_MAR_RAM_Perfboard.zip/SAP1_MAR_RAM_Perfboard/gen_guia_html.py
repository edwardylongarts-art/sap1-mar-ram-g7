# -*- coding: utf-8 -*-
"""Genera Guia_Montaje_MAR_RAM.html: manual visual interactivo con SVGs y checklists."""
import html, math, os
import boards as B

OUT = os.path.dirname(os.path.abspath(__file__))
S = 9.0  # px por mm para SVG nitido

def esc(s):
    return html.escape(str(s))

def svg_board(bd, solder=False):
    Wp, Hp = bd.w * S, bd.h * S
    is_fr4 = (bd.board_style == "fr4_green")
    def X(c):
        x = bd.mx + (c - 1) * B.P
        return (bd.w - x if solder else x) * S
    def Y(r):
        return (bd.my + (r - 1) * B.P) * S

    mx_vb = 84 if is_fr4 else 42
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{-mx_vb} -42 {Wp + 2*mx_vb:.0f} {Hp + 84:.0f}" class="board" data-board="{bd.name}" data-side="{"solder" if solder else "comp"}">']
    if is_fr4:
        bg = "#136638" if solder else "#167842"
        bstroke = "#0b3d22"
    else:
        bg = "#a56327" if solder else "#bc7834"
        bstroke = "#593616"
    o.append(f'<rect x="0" y="0" width="{Wp:.1f}" height="{Hp:.1f}" rx="8" fill="{bg}" stroke="{bstroke}" stroke-width="2.5"/>')

    # Reglas de columnas y filas
    if bd.cmin == 0:
        o.append(f'<text x="{X(0):.1f}" y="-14" class="ax">C0</text>')
        o.append(f'<text x="{X(0):.1f}" y="{Hp + 24:.1f}" class="ax">C0</text>')
    for c in range(1, bd.cols + 1):
        if c == 1 or c % 5 == 0 or c == bd.cols:
            o.append(f'<text x="{X(c):.1f}" y="-14" class="ax">{c}</text>')
            o.append(f'<text x="{X(c):.1f}" y="{Hp + 24:.1f}" class="ax">{c}</text>')
    for r in range(1, bd.rows + 1):
        if r == 1 or r % 5 == 0 or r == bd.rows:
            if not (is_fr4 and not solder):
                o.append(f'<text x="-20" y="{Y(r) + 4:.1f}" class="ax">{r}</text>')
            if not (is_fr4 and solder):
                o.append(f'<text x="{Wp + 20:.1f}" y="{Y(r) + 4:.1f}" class="ax">{r}</text>')

    # Dedos rectangulares de borde (placa verde doble cara PY-7*9 CM)
    if is_fr4:
        for ec in (0, bd.cols + 1):
            ex = X(ec)
            for r in range(1, bd.rows + 1):
                ey = Y(r)
                o.append(f'<rect x="{ex - 14:.1f}" y="{ey - 6.5:.1f}" width="28" height="13" rx="2" fill="#cdd5dc" stroke="#60707b" stroke-width="0.7"/>')

    # Matriz de perforaciones / pads
    for c in range(1, bd.cols + 1):
        for r in range(1, bd.rows + 1):
            cx, cy = X(c), Y(r)
            if is_fr4:
                o.append(f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="6.0" fill="#cfd7de" stroke="#5f6f7a" stroke-width="0.6"/>')
                o.append(f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="2.6" fill="#0d2919"/>')
            elif solder:
                o.append(f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="6.2" fill="#d39652" stroke="#855220" stroke-width="0.6"/>')
                o.append(f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="2.6" fill="#3a2410"/>')
            else:
                o.append(f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="3.0" fill="#3d2511"/>')

    # Puentes de potencia en cara de componentes
    if not solder:
        for w in bd.res["wires"]:
            if w["type"] == "potencia":
                x1, y1, x2, y2 = X(w["a"][0]), Y(w["a"][1]), X(w["b"][0]), Y(w["b"][1])
                o.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{B.COLORS[w["cls"]]}" stroke-width="4.5" stroke-linecap="round" class="w-layer w-potencia"><title>{esc(w["id"])} {esc(w["net"])} (AWG22 cara comp.)</title></line>')

    # Cara de soldadura: rieles, puentes, desnudos, cables aislados
    if solder:
        o.append('<g class="layer-rails">')
        for net, segs in bd.rails.items():
            colr = B.COLORS[B.net_class(net)]
            for a, b_ in segs:
                x1, y1, x2, y2 = X(a[0]), Y(a[1]), X(b_[0]), Y(b_[1])
                o.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="#d8dde3" stroke-width="7.5" stroke-linecap="round"><title>Riel {esc(net)}</title></line>')
                o.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{colr}" stroke-width="2.4" stroke-dasharray="7 6" stroke-linecap="round"/>')
        o.append('</g>')

        o.append('<g class="layer-bridges">')
        for w in bd.res["wires"]:
            if w["type"] in ("puente", "bridge", "desnudo"):
                x1, y1, x2, y2 = X(w["a"][0]), Y(w["a"][1]), X(w["b"][0]), Y(w["b"][1])
                sw = "9.5" if w["type"] in ("puente", "bridge") else "4.4"
                col = "#eef2f6" if w["type"] in ("puente", "bridge") else "#cfd5dc"
                o.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{col}" stroke-width="{sw}" stroke-linecap="round" opacity="0.95"><title>{esc(w["id"])} [{esc(w["net"])}] {esc(w["al"])} -> {esc(w["bl"])}</title></line>')
        o.append('</g>')

        o.append('<g class="layer-isolated">')
        def rounded_poly_d(pts, rad=4.2):
            if len(pts) == 2:
                return f"M{pts[0][0]:.1f} {pts[0][1]:.1f} L{pts[1][0]:.1f} {pts[1][1]:.1f}"
            segs = [f"M{pts[0][0]:.1f} {pts[0][1]:.1f}"]
            for i in range(1, len(pts) - 1):
                x0, y0 = pts[i - 1]; x1, y1 = pts[i]; x2, y2 = pts[i + 1]
                d1 = math.hypot(x1 - x0, y1 - y0) or 1.0
                d2 = math.hypot(x2 - x1, y2 - y1) or 1.0
                r_ = min(rad, d1 * 0.4, d2 * 0.4)
                ax, ay = x1 - (x1 - x0) / d1 * r_, y1 - (y1 - y0) / d1 * r_
                bx, by = x1 + (x2 - x1) / d2 * r_, y1 + (y2 - y1) / d2 * r_
                segs.append(f"L{ax:.1f} {ay:.1f} Q{x1:.1f} {y1:.1f} {bx:.1f} {by:.1f}")
            segs.append(f"L{pts[-1][0]:.1f} {pts[-1][1]:.1f}")
            return " ".join(segs)

        for w in bd.res["wires"]:
            if w["type"] != "aislado":
                continue
            pts = [(X(c), Y(r)) for (c, r) in w["path"]]
            d_str = rounded_poly_d(pts)
            colr = B.COLORS[w["cls"]]
            wid = f"{bd.name}_{w['id']}"
            o.append(f'<g class="wire-grp wc-{w["cls"]}" data-wid="{wid}" data-net="{esc(w["net"])}" onclick="highlightWire(\'{bd.name}\',\'{wid}\')">')
            o.append(f'<path d="{d_str}" fill="none" stroke="#000" stroke-opacity="0.48" stroke-width="5.2" stroke-linecap="round" stroke-linejoin="round"/>')
            o.append(f'<path d="{d_str}" fill="none" stroke="{colr}" stroke-width="2.9" stroke-linecap="round" stroke-linejoin="round"><title>{esc(w["id"])} [{esc(w["net"])}] {esc(w["al"])} -> {esc(w["bl"])} ({w["len_mm"]} mm)</title></path>')
            o.append('</g>')
        o.append('</g>')

    # Contornos de componentes
    o.append('<g class="layer-comps">')
    for comp in bd.comps:
        pads = comp["pads"]
        xs = [X(p["c"]) for p in pads]; ys = [Y(p["r"]) for p in pads]
        x1, x2, y1, y2 = min(xs), max(xs), min(ys), max(ys)
        cx, cy = (x1 + x2) / 2.0, (y1 + y2) / 2.0
        kind = comp["kind"]
        op = 0.24 if solder else 0.96
        stroke = "#00e5ff" if comp["new"] else "#111"
        dash = ' stroke-dasharray="5 3"' if comp["new"] else ""
        tip = f'{comp["ref"]} ({comp["value"]}) - Pin1: C{pads[0]["c"]},F{pads[0]["r"]} - {comp["desc"]}'

        if kind.startswith("DIP"):
            o.append(f'<rect x="{x1 - 7:.1f}" y="{y1 - 9:.1f}" width="{x2 - x1 + 14:.1f}" height="{y2 - y1 + 18:.1f}" rx="4" fill="#181a1f" fill-opacity="{op:.2f}" stroke="{stroke}" stroke-width="1.6"><title>{esc(tip)}</title></rect>')
            if comp["rot"] == 180:
                o.append(f'<path d="M{cx - 7:.1f} {y2 + 9:.1f} a7 7 0 0 1 14 0" fill="#4f5664" opacity="{op:.2f}"/>')
            else:
                o.append(f'<path d="M{cx - 7:.1f} {y1 - 9:.1f} a7 7 0 0 0 14 0" fill="#4f5664" opacity="{op:.2f}"/>')
            o.append(f'<circle cx="{X(pads[0]["c"]):.1f}" cy="{Y(pads[0]["r"]):.1f}" r="5.5" fill="none" stroke="#ff3d3d" stroke-width="2"/>')
            o.append(f'<text x="{cx:.1f}" y="{cy:.1f}" class="ic" transform="rotate(-90 {cx:.1f} {cy:.1f})">{esc(comp["ref"])} {esc(comp["value"])}</text>')
        elif kind == "LED5":
            col = comp["render"].get("color", "#ff2b2b")
            o.append(f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="{2.7 * S:.1f}" fill="{col}" fill-opacity="{0.82 if not solder else 0.28:.2f}" stroke="#111" stroke-width="1.4"><title>{esc(tip)}</title></circle>')
            kx, ky = X(pads[0]["c"]), Y(pads[0]["r"])
            if abs(X(pads[1]["c"]) - kx) >= abs(Y(pads[1]["r"]) - ky):
                o.append(f'<line x1="{kx:.1f}" y1="{cy - 2.3 * S:.1f}" x2="{kx:.1f}" y2="{cy + 2.3 * S:.1f}" stroke="#111" stroke-width="2.4"/>')
            else:
                o.append(f'<line x1="{cx - 2.3 * S:.1f}" y1="{ky:.1f}" x2="{cx + 2.3 * S:.1f}" y2="{ky:.1f}" stroke="#111" stroke-width="2.4"/>')
            o.append(f'<text x="{cx:.1f}" y="{cy - 3.2 * S:.1f}" class="lb">{esc(comp["ref"])}</text>')
        elif kind == "R762":
            vert = (y2 - y1) > (x2 - x1)
            rfill = "#38a4d0" if is_fr4 else "#e6cf98"
            if vert:
                o.append(f'<rect x="{cx - 9:.1f}" y="{y1 + 6:.1f}" width="18" height="{y2 - y1 - 12:.1f}" rx="5" fill="{rfill}" fill-opacity="{op:.2f}" stroke="{stroke}" stroke-width="1.3"{dash}><title>{esc(tip)}</title></rect>')
                o.append(f'<text x="{cx:.1f}" y="{cy + 3:.1f}" class="sm" transform="rotate(-90 {cx:.1f} {cy:.1f})">{esc(comp["ref"])}</text>')
            else:
                o.append(f'<rect x="{x1 + 6:.1f}" y="{cy - 9:.1f}" width="{x2 - x1 - 12:.1f}" height="18" rx="5" fill="{rfill}" fill-opacity="{op:.2f}" stroke="{stroke}" stroke-width="1.3"{dash}><title>{esc(tip)}</title></rect>')
                o.append(f'<text x="{cx:.1f}" y="{cy + 3:.1f}" class="sm">{esc(comp["ref"])}</text>')
        elif kind in ("C254", "C508"):
            w_ = max(14.0, (x2 - x1) + 8)
            h_ = max(14.0, (y2 - y1) + 8)
            o.append(f'<rect x="{cx - w_/2:.1f}" y="{cy - h_/2:.1f}" width="{w_:.1f}" height="{h_:.1f}" rx="6" fill="#eb9132" fill-opacity="{op:.2f}" stroke="{stroke}" stroke-width="1.4"{dash}><title>{esc(tip)}</title></rect>')
            o.append(f'<text x="{cx:.1f}" y="{cy + 3:.1f}" class="sm">{esc(comp["ref"])}</text>')
        elif kind == "CP5":
            o.append(f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="{2.4 * S:.1f}" fill="#1f4999" fill-opacity="{op:.2f}" stroke="{stroke}" stroke-width="1.6"{dash}><title>{esc(tip)}</title></circle>')
            o.append(f'<text x="{X(pads[0]["c"]):.1f}" y="{Y(pads[0]["r"]) + 4:.1f}" class="plus">+</text>')
            o.append(f'<text x="{cx:.1f}" y="{cy - 2.9 * S:.1f}" class="lb">{esc(comp["ref"])}</text>')
        elif kind.startswith("SWDIP"):
            is_piano = "KSPA" in comp["value"]
            sfill = "#22252b" if is_piano else "#c72020"
            o.append(f'<rect x="{x1 - 12:.1f}" y="{y1 - 8:.1f}" width="{x2 - x1 + 24:.1f}" height="{y2 - y1 + 16:.1f}" rx="4" fill="{sfill}" fill-opacity="{op:.2f}" stroke="#111" stroke-width="1.6"><title>{esc(tip)}</title></rect>')
            if is_piano and not solder:
                for p in pads[:4]:
                    px = X(p["c"])
                    o.append(f'<rect x="{px - 5:.1f}" y="{y2 + 6:.1f}" width="10" height="10" rx="1.5" fill="#f0f2f5" stroke="#111" stroke-width="1"/>')
            o.append(f'<text x="{cx:.1f}" y="{cy + 4:.1f}" class="ic">{esc(comp["ref"])} ({esc(comp["value"])})</text>')
        elif kind.startswith("SIP"):
            o.append(f'<rect x="{x1 - 8:.1f}" y="{cy - 9:.1f}" width="{x2 - x1 + 16:.1f}" height="18" rx="4" fill="#efc12c" fill-opacity="{op:.2f}" stroke="{stroke}" stroke-width="1.4"{dash}><title>{esc(tip)}</title></rect>')
            o.append(f'<circle cx="{X(pads[0]["c"]):.1f}" cy="{Y(pads[0]["r"]):.1f}" r="4.5" fill="#111"/>')
            o.append(f'<text x="{cx:.1f}" y="{cy + 3.5:.1f}" class="sm">{esc(comp["ref"])} {esc(comp["value"])}</text>')
        elif kind == "SPDT3":
            o.append(f'<rect x="{cx - 17:.1f}" y="{y1 - 10:.1f}" width="34" height="{y2 - y1 + 20:.1f}" rx="4" fill="#b4bcc4" fill-opacity="{op:.2f}" stroke="#111" stroke-width="1.6"><title>{esc(tip)}</title></rect>')
            o.append(f'<rect x="{cx - 8:.1f}" y="{y1 - 2:.1f}" width="16" height="18" rx="2" fill="#1b1e24" fill-opacity="{op:.2f}" stroke="#eee" stroke-width="0.9"/>')
            o.append(f'<text x="{cx:.1f}" y="{y2 + 24:.1f}" class="lb">{esc(comp["ref"])} SPDT</text>')
        elif kind == "EDGE14":
            labs = comp["render"].get("labels") or []
            for idx_p, (pd, lab) in enumerate(zip(pads, labs), 1):
                px, py = X(pd["c"]), Y(pd["r"])
                o.append(f'<rect x="{px - 15:.1f}" y="{py - 7:.1f}" width="30" height="14" rx="2" fill="#f0c441" fill-opacity="0.92" stroke="#111" stroke-width="1.1"><title>{esc(comp["ref"])}.{idx_p} = {esc(lab)} (C0, F{pd["r"]})</title></rect>')
                if solder:
                    o.append(f'<text x="{px + 22:.1f}" y="{py + 3.8:.1f}" class="hl">{idx_p}. {esc(lab)}</text>')
                else:
                    o.append(f'<text x="{px - 22:.1f}" y="{py + 3.8:.1f}" class="hr">{esc(lab)} .{idx_p}</text>')
        elif kind in ("PUSH6", "LOCK6"):
            pad_e = 6 if kind == "PUSH6" else 11
            o.append(f'<rect x="{x1 - pad_e:.1f}" y="{y1 - pad_e:.1f}" width="{x2 - x1 + 2*pad_e:.1f}" height="{y2 - y1 + 2*pad_e:.1f}" rx="5" fill="#2b303a" fill-opacity="{op:.2f}" stroke="#111" stroke-width="1.6"><title>{esc(tip)}</title></rect>')
            o.append(f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="14" fill="{"#c72020" if kind=="LOCK6" else "#111"}" fill-opacity="{op:.2f}" stroke="#ddd" stroke-width="1.2"/>')
            o.append(f'<text x="{cx:.1f}" y="{y1 - pad_e - 5:.1f}" class="lb">{esc(comp["ref"])} {esc(comp["value"])}</text>')
        elif kind.startswith("HDR"):
            o.append(f'<rect x="{x1 - 9:.1f}" y="{y1 - 9:.1f}" width="{x2 - x1 + 18:.1f}" height="{y2 - y1 + 18:.1f}" rx="3" fill="#191b20" fill-opacity="{op:.2f}" stroke="#eab738" stroke-width="1.6"><title>{esc(tip)}</title></rect>')
            labs = comp["render"].get("labels") or []
            horiz = comp["rot"] in (90, 270)
            for pd, lab in zip(pads, labs):
                px, py = X(pd["c"]), Y(pd["r"])
                if lab == "LLAVE":
                    o.append(f'<line x1="{px - 5:.1f}" y1="{py - 5:.1f}" x2="{px + 5:.1f}" y2="{py + 5:.1f}" stroke="#ff4444" stroke-width="2"/>')
                    o.append(f'<line x1="{px + 5:.1f}" y1="{py - 5:.1f}" x2="{px - 5:.1f}" y2="{py + 5:.1f}" stroke="#ff4444" stroke-width="2"/>')
                else:
                    o.append(f'<rect x="{px - 3.5:.1f}" y="{py - 3.5:.1f}" width="7" height="7" fill="#f0c441"/>')
                if not solder:
                    if horiz:
                        dy = -16 if pd["r"] > bd.rows / 2 else 22
                        o.append(f'<text x="{px:.1f}" y="{py + dy:.1f}" class="hl" transform="rotate(-55 {px:.1f} {py + dy:.1f})">{esc(lab)}</text>')
                    else:
                        o.append(f'<text x="{px - 14:.1f}" y="{py + 3.5:.1f}" class="hr">{esc(lab)}</text>')
    o.append('</g></svg>')
    return "\n".join(o)

def comp_table(bd):
    rows = []
    for c in bd.comps:
        p1 = c["pads"][0]
        tag = '<span class="tag-new">MEJORA</span>' if c["new"] else '<span class="tag-orig">ESQUEMA</span>'
        rows.append(f'<tr><td><b>{esc(c["ref"])}</b></td><td>{esc(c["value"])}</td><td><code>C{p1["c"]}, F{p1["r"]}</code></td><td>{c["rot"]}°</td><td>{tag}</td><td>{esc(c["desc"])}</td></tr>')
    return "\n".join(rows)

def wire_table(bd):
    rows = []
    for w in bd.res["wires"]:
        cid = f"{bd.name}_{w['id']}"
        dot = f'<span class="dot" style="background:{B.COLORS[w["cls"]]}"></span>'
        rows.append(
            f'<tr data-cls="{w["cls"]}" data-type="{w["type"]}" data-wid="{cid}" onclick="if(event.target.type!==\'checkbox\')highlightWire(\'{bd.name}\',\'{cid}\')" style="cursor:pointer">'
            f'<td><input type="checkbox" class="wchk" data-key="{cid}"></td>'
            f'<td><b>{esc(w["id"])}</b></td>'
            f'<td>{dot}<b>{esc(w["net"])}</b></td>'
            f'<td>{esc(B.TYPE_ES[w["type"]])}</td>'
            f'<td><code>{esc(w["al"])} (C{w["a"][0]},F{w["a"][1]})</code></td>'
            f'<td><code>{esc(w["bl"])} (C{w["b"][0]},F{w["b"][1]})</code></td>'
            f'<td>{w["len_mm"]} mm</td></tr>'
        )
    return "\n".join(rows)

def stats_cards(bd):
    W = bd.res["wires"]
    pu = sum(1 for w in W if w["type"] in ("puente", "bridge"))
    de = sum(1 for w in W if w["type"] == "desnudo")
    ai = sum(1 for w in W if w["type"] == "aislado")
    mm = sum(w["len_mm"] for w in W if w["type"] == "aislado")
    n_disc = sum(1 for c in bd.comps if c["kind"] != "EDGE14")
    has_edge = any(c["kind"] == "EDGE14" for c in bd.comps)
    comp_lbl = f"{n_disc} (+14 pads borde)" if has_edge else f"{n_disc}"
    grid_lbl = f"{bd.cols} × {bd.rows} (+ borde C0)" if bd.cmin == 0 else f"{bd.cols} × {bd.rows} pads"
    return f"""<div class="stats">
      <div class="stat"><span>Cuadrícula usada</span><b>{grid_lbl}</b></div>
      <div class="stat"><span>Componentes</span><b>{comp_lbl}</b></div>
      <div class="stat"><span>Conexiones totales</span><b>{len(W)}</b></div>
      <div class="stat"><span>Puentes / Rectos</span><b>{pu} / {de}</b></div>
      <div class="stat"><span>Cables AWG 30</span><b>{ai} ({mm/1000:.2f} m)</b></div>
    </div>"""

def generate():
    mar, ram = B.build_mar(), B.build_ram()
    doc = f"""<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Guia de Montaje en Baquelita — SAP-1 MAR (7×9 cm) y RAM (9×15 cm)</title>
<style>
  :root{{--bg:#0f141e;--card:#171f2e;--line:#2a354b;--txt:#e8eef7;--mut:#9fb0c9;--acc:#4a90ff}}
  *{{box-sizing:border-box}}
  body{{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:var(--bg);color:var(--txt);margin:0;line-height:1.5}}
  .wrap{{max-width:1360px;margin:0 auto;padding:22px 20px 60px}}
  header{{background:linear-gradient(135deg,#18243a,#121927);border:1px solid var(--line);border-radius:14px;padding:22px 26px;margin-bottom:20px}}
  h1{{margin:0 0 6px;font-size:24px;color:#fff}}
  h2{{margin:26px 0 12px;font-size:19px;color:#7ab4ff;border-bottom:1px solid var(--line);padding-bottom:6px}}
  h3{{margin:16px 0 8px;font-size:15px;color:#dce8fa}}
  p.sub{{margin:0;color:var(--mut);font-size:14px}}
  .tabs{{display:flex;gap:8px;margin:18px 0;flex-wrap:wrap}}
  .tab{{background:#1b2538;color:#c7d5ec;border:1px solid var(--line);padding:9px 16px;border-radius:9px;cursor:pointer;font-weight:700;font-size:13.5px}}
  .tab.active{{background:var(--acc);color:#fff;border-color:var(--acc)}}
  .pane{{display:none}}.pane.active{{display:block}}
  .card{{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:18px;margin-bottom:18px}}
  .stats{{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px;margin:12px 0}}
  .stat{{background:#111826;border:1px solid var(--line);border-radius:9px;padding:10px 14px}}
  .stat span{{display:block;font-size:11.5px;color:var(--mut)}}
  .stat b{{font-size:18px;color:#fff}}
  .toolbar{{display:flex;flex-wrap:wrap;gap:12px;align-items:center;margin-bottom:12px;background:#111722;padding:10px 14px;border-radius:9px;border:1px solid var(--line);font-size:13px}}
  .svg-grid{{display:grid;grid-template-columns:1fr;gap:18px}}
  svg.board{{width:100%;height:auto;max-height:760px;background:#0b0f17;border-radius:10px;border:1px solid var(--line)}}
  svg text.ax{{font:700 13px monospace;fill:#9bb0cc;text-anchor:middle}}
  svg text.ic{{font:700 13px monospace;fill:#eef4ff;text-anchor:middle;dominant-baseline:central}}
  svg text.lb{{font:700 11px sans-serif;fill:#fff;text-anchor:middle}}
  svg text.sm{{font:700 9.5px monospace;fill:#111;text-anchor:middle}}
  svg text.plus{{font:700 13px monospace;fill:#fff;text-anchor:middle}}
  svg text.hr{{font:700 10px monospace;fill:#ffd86b;text-anchor:end}}
  svg text.hl{{font:700 10px monospace;fill:#ffd86b;text-anchor:start}}
  table{{width:100%;border-collapse:collapse;font-size:12.5px}}
  th,td{{padding:7px 9px;border-bottom:1px solid #243046;text-align:left}}
  th{{background:#111826;color:#9cc2ff;position:sticky;top:0}}
  tr.done td{{opacity:.45;text-decoration:line-through}}
  code{{background:#0e1420;padding:2px 6px;border-radius:5px;color:#8be9fd;font-size:12px}}
  .dot{{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:6px;vertical-align:middle;border:1px solid rgba(255,255,255,.35)}}
  .tag-orig{{background:#1d3352;color:#8cc0ff;padding:2px 6px;border-radius:4px;font-size:10.5px;font-weight:700}}
  .tag-new{{background:#0d4652;color:#5ef2ff;padding:2px 6px;border-radius:4px;font-size:10.5px;font-weight:700}}
  .alert{{background:#241c10;border-left:4px solid #f0b400;padding:12px 16px;border-radius:8px;margin:12px 0;font-size:13.5px}}
  .tbl-box{{max-height:460px;overflow:auto;border:1px solid var(--line);border-radius:8px}}
  .pills{{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px}}
  .pill{{background:#1b2538;color:#d0dcf0;border:1px solid #2c3b55;padding:4px 10px;border-radius:20px;cursor:pointer;font-size:12px;font-weight:600}}
  .pill.active{{background:#2b6ef2;color:#fff;border-color:#2b6ef2}}
  svg .wire-grp{{cursor:pointer;transition:opacity .15s}}
  svg.has-hl .wire-grp{{opacity:0.12}}
  svg.has-hl .wire-grp.hl{{opacity:1}}
  svg.has-hl .wire-grp.hl path:first-child{{stroke:#00f0ff;stroke-opacity:0.95;stroke-width:8.5}}
  tr.hl-row{{background:#1c355c!important}}
  @media print{{
    body{{background:#fff;color:#000}}
    .card,header{{background:#fff;border-color:#ccc}}
    .tabs,.toolbar{{display:none}}
    .pane{{display:block!important}}
    .tbl-box{{max-height:none;overflow:visible}}
  }}
</style>
</head>
<body>
<div class="wrap">
<header>
  <h1>SAP-1 en Baquelita Perforada (2.54 mm) — Módulos MAR (7×9 cm) y RAM (9×15 cm)</h1>
  <p class="sub">Diseñado a partir de <b>mar.sch</b> y <b>ram.sch</b> reales · 0 errores eléctricos · 0 colisiones mecánicas 3D · Coordenadas <code>(C, F)</code> vistas desde la cara de componentes (arriba-izquierda = C1, F1).</p>
</header>

<div class="tabs">
  <button class="tab active" data-tab="t-mar">1. Módulo MAR (7×9 cm)</button>
  <button class="tab" data-tab="t-ram">2. Módulo RAM (9×15 cm)</button>
  <button class="tab" data-tab="t-tips">3. Mejoras, Pines y Soldadura</button>
</div>

<div class="pane active" id="t-mar">
  <div class="card">
    <h2>Módulo MAR — 7 × 9 cm (PY-7*9 CM: {mar.cols} columnas × {mar.rows} filas + pads de borde C0)</h2>
    {stats_cards(mar)}
    <div class="toolbar">
      <b>Capas (Cara Soldadura):</b>
      <label><input type="checkbox" checked onchange="toggleLayer('MAR','.layer-rails',this.checked)"> Riel GND (en C)</label>
      <label><input type="checkbox" checked onchange="toggleLayer('MAR','.layer-bridges',this.checked)"> Puentes de estaño / alambre recto</label>
      <label><input type="checkbox" checked onchange="toggleLayer('MAR','.layer-isolated',this.checked)"> Cables AWG 30 (ortogonales)</label>
      <label><input type="checkbox" checked onchange="toggleLayer('MAR','.layer-comps',this.checked)"> Silueta</label>
    </div>
    <div class="pills" data-pboard="MAR">
      <button class="pill active" onclick="filterBus('MAR','ALL',this)">Todos los buses</button>
      <button class="pill" onclick="filterBus('MAR','bus',this)"><span class="dot" style="background:#1e6fff"></span>Bus W (BUS_0..3)</button>
      <button class="pill" onclick="filterBus('MAR','addr',this)"><span class="dot" style="background:#f0be00"></span>Direcciones / PROG</button>
      <button class="pill" onclick="filterBus('MAR','data',this)"><span class="dot" style="background:#19b34a"></span>Q0..Q3 (U34→U33)</button>
      <button class="pill" onclick="filterBus('MAR','dip',this)"><span class="dot" style="background:#e8e8e8"></span>DIP SW5</button>
      <button class="pill" onclick="filterBus('MAR','ctrl',this)"><span class="dot" style="background:#ff7b00"></span>Control / Reloj</button>
      <button class="pill" onclick="filterBus('MAR','vcc',this)"><span class="dot" style="background:#e01e1e"></span>VCC (+5V)</button>
      <button class="pill" onclick="filterBus('MAR','gnd',this)"><span class="dot" style="background:#222"></span>GND</button>
      <button class="pill" onclick="clearHl('MAR')">Quitar resaltado</button>
    </div>
    <div class="svg-grid">
      <div><h3>Cara de Componentes (Vista Superior — coincide con <code>Cara componentes.jpeg</code>)</h3>{svg_board(mar, False)}</div>
      <div><h3>Cara de Soldadura (ESPEJADA — coincide con <code>cara soldadura.jpeg</code>, pads <code>P_EXT</code> en el borde derecho)</h3>{svg_board(mar, True)}</div>
    </div>
  </div>
  <div class="card">
    <h2>Ubicación exacta de componentes — MAR</h2>
    <div class="tbl-box"><table><thead><tr><th>Ref</th><th>Valor</th><th>Pin 1 (C, F)</th><th>Rot.</th><th>Origen</th><th>Descripción</th></tr></thead><tbody>{comp_table(mar)}</tbody></table></div>
  </div>
  <div class="card">
    <h2>Checklist interactivo de cableado — MAR (se guarda automáticamente)</h2>
    <div class="tbl-box"><table><thead><tr><th>OK</th><th>#</th><th>Red</th><th>Método</th><th>Desde</th><th>Hasta</th><th>Largo</th></tr></thead><tbody>{wire_table(mar)}</tbody></table></div>
  </div>
</div>

<div class="pane" id="t-ram">
  <div class="card">
    <h2>Módulo RAM 16×8 — 9 × 15 cm (51 columnas × 30 filas)</h2>
    {stats_cards(ram)}
    <div class="toolbar">
      <b>Capas (Cara Soldadura):</b>
      <label><input type="checkbox" checked onchange="toggleLayer('RAM','.layer-rails',this.checked)"> Rieles VCC/GND</label>
      <label><input type="checkbox" checked onchange="toggleLayer('RAM','.layer-bridges',this.checked)"> Puentes de estaño / alambre recto</label>
      <label><input type="checkbox" checked onchange="toggleLayer('RAM','.layer-isolated',this.checked)"> Cables AWG 30 (ortogonales)</label>
      <label><input type="checkbox" checked onchange="toggleLayer('RAM','.layer-comps',this.checked)"> Silueta</label>
    </div>
    <div class="pills" data-pboard="RAM">
      <button class="pill active" onclick="filterBus('RAM','ALL',this)">Todos los buses</button>
      <button class="pill" onclick="filterBus('RAM','bus',this)"><span class="dot" style="background:#1e6fff"></span>Solo Bus W (8 hilos)</button>
      <button class="pill" onclick="filterBus('RAM','data',this)"><span class="dot" style="background:#19b34a"></span>Solo Datos internos</button>
      <button class="pill" onclick="filterBus('RAM','addr',this)"><span class="dot" style="background:#f0be00"></span>Solo Direcciones / PROG</button>
      <button class="pill" onclick="filterBus('RAM','dip',this)"><span class="dot" style="background:#e8e8e8"></span>Solo DIP SW3</button>
      <button class="pill" onclick="filterBus('RAM','ctrl',this)"><span class="dot" style="background:#ff7b00"></span>Solo Control / ~WE</button>
      <button class="pill" onclick="filterBus('RAM','gnd',this)"><span class="dot" style="background:#222"></span>Solo GND</button>
      <button class="pill" onclick="clearHl('RAM')">Quitar resaltado</button>
    </div>
    <div class="svg-grid">
      <div><h3>Cara de Componentes (Vista Superior — orientación de montaje)</h3>{svg_board(ram, False)}</div>
      <div><h3>Cara de Soldadura (ESPEJADA — vista real al voltear la placa para soldar)</h3>{svg_board(ram, True)}</div>
    </div>
  </div>
  <div class="card">
    <h2>Ubicación exacta de componentes — RAM</h2>
    <div class="tbl-box"><table><thead><tr><th>Ref</th><th>Valor</th><th>Pin 1 (C, F)</th><th>Rot.</th><th>Origen</th><th>Descripción</th></tr></thead><tbody>{comp_table(ram)}</tbody></table></div>
  </div>
  <div class="card">
    <h2>Checklist interactivo de cableado — RAM (se guarda automáticamente)</h2>
    <div class="tbl-box"><table><thead><tr><th>OK</th><th>#</th><th>Red</th><th>Método</th><th>Desde</th><th>Hasta</th><th>Largo</th></tr></thead><tbody>{wire_table(ram)}</tbody></table></div>
  </div>
</div>

<div class="pane" id="t-tips">
  <div class="card">
    <h2>Especificaciones fieles al montaje real (MAR) y diagramas del profesor (mar.sch / ram.sch)</h2>
    <ul>
      <li><b>Módulo MAR fiel al prototipo real (placa FR-4 doble cara <code>PY-7*9 CM</code>):</b> Integrados <code>U34</code> (<code>SN74LS173AN</code>) y <code>U33</code> (<code>SN74LS157N</code>) montados con la <b>muesca orientada hacia abajo (180°)</b>, DIP switch piano <code>SW5</code> (<code>KSPA04-NB</code>, D3..D0), 4 LEDs <b>rojos</b> de dirección (<code>D44..D47</code>) con sus 4 resistencias de <code>220 Ω</code> (<code>R59..R62</code>) en la zona inferior izquierda, y bloque de modo a la derecha (LED verde RUN <code>D49</code>, LED rojo PROG <code>D48</code>, <code>R63/R64 = 1 kΩ</code> e interruptor deslizable SPDT <code>SW6</code>).</li>
      <li><b>Interfaz directa en los pads de borde del MAR (<code>P_EXT</code>):</b> Sin headers <code>J1/J2</code> separados; todas las 14 señales externas salen por los pads rectangulares del borde (lado derecho visto desde la cara de soldadura) en el orden exacto del montaje físico: <code>GND, CLR, CLK, ~MI, BUS_0, BUS_1, BUS_2, BUS_3, VCC, A3, A2, A1, A0, PROG</code>.</li>
      <li><b>Desacoplo fiel a los esquemáticos originales:</b>
        <ul>
          <li><b>MAR:</b> únicamente <b>UN (1) capacitor cerámico <code>C18 = 100 nF (0.1 µF)</code></b> al principio de <code>VCC → GND</code> (eliminados los extras C19, C20, RN1 y R69).</li>
          <li><b>RAM:</b> únicamente <b>DOS (2) capacitores cerámicos <code>C16</code> y <code>C17 = 100 nF (0.1 µF)</code> en paralelo</b> al principio de <code>VCC → GND</code> junto a <code>J3</code> (eliminados C21–C27 y el electrolítico bulk C28), conservando intacto el capacitor funcional <b><code>C7 = 10 nF (0.01 µF)</code></b> junto a <code>R58 = 1 kΩ</code> del detector de flanco RC en <code>CLK</code>.</li>
        </ul>
      </li>
      <li><b>Pinout real intercalado de las <code>74LS189</code> (<code>U24</code> y <code>U25</code>):</b> Se respetó exactamente el pinout real (<code>4=D1, 5=~O1, 6=D2, 7=~O2, 9=~O3, 10=D3, 11=~O4, 12=D4</code> y <code>15=A1, 14=A2, 13=A3</code>), alineando <code>U26/U27</code> directamente sobre <code>U24/U25</code> para acortar las líneas de datos.</li>
      <li><b>Variante con memorias <code>7489 / 74LS89</code> (alternativa práctica):</b> Mismo pinout DIP-16 y mismas salidas invertidas (mantiene <code>U28</code> y <code>U29</code> <code>74LS04</code>), pero al tener <b>salidas de colector abierto (open-collector)</b> requiere añadir obligatoriamente <b>8 resistencias pull-up externas de 1 kΩ – 4.7 kΩ a +5 V</b> (p. ej. 1 red SIP-9 <code>8×2.2 kΩ</code> o <code>8×4.7 kΩ</code>) en las líneas <code>~DO7..~DO0</code> entre <code>U24/U25</code> y <code>U28/U29</code>. Durante escritura (<code>~WE=0</code>), el <code>74LS245</code> (<code>U30</code> con <code>~RO=1</code>) mantiene aislado el Bus W sin contienda.</li>
      <li><b>Alineación 1 a 1 del Bus W (<code>U30 → J3</code>):</b> El transceptor <code>74LS245</code> queda frente al header <code>J3</code>: <code>~RO</code> y <code>BUS_7..BUS_0</code> cruzan en <b>9 pistas rectas paralelas de solo 3 huecos (7.62 mm)</b> sin un solo cruce.</li>
      <li><b>Interconexión MAR → RAM (6 hilos en bordes enfrentados):</b> Desde los pads de borde del MAR <code>P_EXT.1 (GND)</code>, <code>P_EXT.14 (PROG)</code> y <code>P_EXT.10..13 (A3..A0)</code> hacia el header <b><code>RAM J1</code> ubicado en el borde izquierdo (<code>C1, F19..F24</code>)</b>, en el lado opuesto al Bus W/control (<code>J3</code> en el borde derecho <code>C50</code>).</li>
      <li><b>Fidelidad directa a <code>ram.sch</code> (sin <code>RN2</code> ni <code>R70</code>) y entradas no usadas a GND:</b> Las líneas <code>SW_D7..SW_D0</code> del DIP <code>SW3</code> y el pulsador <code>SW4</code> (<code>WRITE</code>) se conectan directamente a <code>U26</code>, <code>U27</code> y <code>U32</code> tal como en el diagrama original del profesor, y todas las compuertas sobrantes en <code>U28, U29, U31, U32</code> se atan a GND.</li>
    </ul>
    <div class="alert">
      <b>Advertencias clave al soldar en placa perforada (FR-4 / baquelita FR-2):</b>
      <ol>
        <li><b>Rieles VCC y GND:</b> Nunca dependas solo de cable AWG 30 para la alimentación principal. Tiende <b>alambre de cobre desnudo AWG 20–22</b> por el riel de masa en forma de C del MAR y por los rieles VCC/GND de la RAM, soldando cada pad en &lt;2 s a ~330 °C.</li>
        <li><b>Zócalos DIP en todos los ICs:</b> Imprescindibles, especialmente en <code>U34/U33</code> y en las memorias <code>74LS189 / 7489</code>.</li>
        <li><b>Resistencias de LEDs:</b> El esquema original marca <code>220 Ω</code> (usado en el MAR físico); en la RAM es recomendable usar entre <code>470 Ω</code> y <code>1 kΩ</code> para reducir el consumo total cuando los 8 LEDs están encendidos simultáneamente.</li>
        <li><b>Cable delgado:</b> Usa <b>Kynar / wire-wrap AWG 30</b> o siliconado AWG 28; el forro PVC barato se derrite con el calor de pads vecinos a 2.54 mm.</li>
        <li><b>Orden recomendado de soldadura:</b> (1) Rieles VCC/GND de alambre desnudo → (2) Zócalos DIP, resistencias, capacitores, switches y headers → (3) Puentes de estaño adyacentes → (4) Alambres rectos desnudos → (5) Cables aislados AWG 30 → (6) Verificar continuidad y ausencia de corto VCC-GND antes de insertar los ICs.</li>
      </ol>
    </div>
  </div>
</div>
</div>
<script>
document.querySelectorAll('.tab').forEach(btn => btn.onclick = () => {{
  document.querySelectorAll('.tab,.pane').forEach(el => el.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById(btn.dataset.tab).classList.add('active');
}});
function toggleLayer(board, sel, show) {{
  document.querySelectorAll(`svg[data-board="${{board}}"] ${{sel}}`).forEach(g => g.style.display = show ? '' : 'none');
}}
function filterBus(board, cls, btn) {{
  document.querySelectorAll(`.pills[data-pboard="${{board}}"] .pill`).forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  clearHl(board);
  document.querySelectorAll(`svg[data-board="${{board}}"] .wire-grp`).forEach(g => {{
    g.style.display = (cls === 'ALL' || g.classList.contains('wc-' + cls)) ? '' : 'none';
  }});
}}
function highlightWire(board, wid) {{
  const svg = document.querySelector(`svg[data-board="${{board}}"][data-side="solder"]`);
  if (!svg) return;
  const target = svg.querySelector(`.wire-grp[data-wid="${{wid}}"]`);
  const already = target && target.classList.contains('hl');
  clearHl(board);
  if (!already && target) {{
    svg.classList.add('has-hl');
    target.style.display = '';
    target.classList.add('hl');
    const tr = document.querySelector(`tr[data-wid="${{wid}}"]`);
    if (tr) tr.classList.add('hl-row');
  }}
}}
function clearHl(board) {{
  const svg = document.querySelector(`svg[data-board="${{board}}"][data-side="solder"]`);
  if (svg) {{
    svg.classList.remove('has-hl');
    svg.querySelectorAll('.wire-grp.hl').forEach(g => g.classList.remove('hl'));
  }}
  document.querySelectorAll('tr.hl-row').forEach(r => r.classList.remove('hl-row'));
}}
document.querySelectorAll('.wchk').forEach(chk => {{
  const k = 'sap1_' + chk.dataset.key;
  if (localStorage.getItem(k) === '1') {{ chk.checked = true; chk.closest('tr').classList.add('done'); }}
  chk.onchange = () => {{
    localStorage.setItem(k, chk.checked ? '1' : '0');
    chk.closest('tr').classList.toggle('done', chk.checked);
  }};
}});
</script>
</body>
</html>"""
    with open(os.path.join(OUT, "Guia_Montaje_MAR_RAM.html"), "w", encoding="utf-8") as f:
        f.write(doc)
    print("Generado Guia_Montaje_MAR_RAM.html correctamente.")

if __name__ == "__main__":
    generate()
