# -*- coding: utf-8 -*-
"""Genera archivos KiCad 9 (.kicad_pcb) con modelos 3D y listas CSV de cableado."""
import csv, os, uuid
import boards as B

OUT = os.path.dirname(os.path.abspath(__file__))
M3D = "${KICAD9_3DMODEL_DIR}/"

def uid():
    return str(uuid.uuid4())

def export_kicad(board, fname):
    X0, Y0 = 100.0, 60.0
    def xy(c, r):
        x, y = board.xy(c, r)
        return (X0 + x, Y0 + y)

    nets = ["GND", "VCC"] + sorted(n for n in board.nets if n not in ("GND", "VCC"))
    nid = {n: i + 1 for i, n in enumerate(nets)}
    L = [
        '(kicad_pcb (version 20240108) (generator "sap1_perfboard_gen") (generator_version "9.0")',
        '  (general (thickness 1.6) (legacy_teardrops no))',
        '  (paper "A4")',
        f'  (title_block (title "{board.title}") (comment 1 "Placa perforada 2.54 mm - MAR/RAM SAP-1"))',
        '''  (layers
    (0 "F.Cu" signal) (31 "B.Cu" signal) (32 "B.Adhes" user "B.Adhesive") (33 "F.Adhes" user "F.Adhesive")
    (34 "B.Paste" user) (35 "F.Paste" user) (36 "B.SilkS" user "B.Silkscreen") (37 "F.SilkS" user "F.Silkscreen")
    (38 "B.Mask" user) (39 "F.Mask" user) (40 "Dwgs.User" user "User.Drawings") (41 "Cmts.User" user "User.Comments")
    (42 "Eco1.User" user "User.Eco1") (43 "Eco2.User" user "User.Eco2") (44 "Edge.Cuts" user) (45 "Margin" user)
    (46 "B.CrtYd" user "B.Courtyard") (47 "F.CrtYd" user "F.Courtyard") (48 "B.Fab" user) (49 "F.Fab" user))''',
        '  (setup (pad_to_mask_clearance 0))',
        '  (net 0 "")',
    ]
    for n in nets:
        L.append(f'  (net {nid[n]} "{n}")')

    pin_net = board.res["pin_net"]
    used = set()
    for comp in board.comps:
        k = B.KINDS[comp["kind"]]
        p1 = comp["pads"][0]
        ax, ay = xy(p1["c"], p1["r"])
        rot = comp["rot"] % 360
        is_edge = comp["kind"] == "EDGE14"
        L.append(f'  (footprint "{k["fp"]}" (layer "F.Cu") (uuid "{uid()}") (at {ax:.3f} {ay:.3f} {rot})')
        L.append(f'    (property "Reference" "{comp["ref"]}" (at 0 -2.2 {rot}) (layer "F.SilkS") (uuid "{uid()}") (effects (font (size 1 1) (thickness 0.15))))')
        L.append(f'    (property "Value" "{comp["value"]}" (at 0 2.2 {rot}) (layer "F.Fab") (uuid "{uid()}") (effects (font (size 1 1) (thickness 0.15))))')
        L.append(f'    (property "Footprint" "{k["fp"]}" (at 0 0 {rot}) (layer "F.Fab") (hide yes) (uuid "{uid()}") (effects (font (size 1 1) (thickness 0.15))))')
        L.append(f'    (property "Description" "{comp["desc"]}" (at 0 0 {rot}) (layer "F.Fab") (hide yes) (uuid "{uid()}") (effects (font (size 1 1) (thickness 0.15))))')
        L.append('    (attr smd)' if is_edge else '    (attr through_hole)')
        for pd in comp["pads"]:
            used.add((pd["c"], pd["r"]))
            px, py = xy(pd["c"], pd["r"])
            lx, ly = B.rotate(px - ax, py - ay, -rot)
            key = f'{comp["ref"]}.{pd["name"]}'
            net = pin_net.get(key)
            ns = f' (net {nid[net]} "{net}")' if net else ""
            if is_edge:
                L.append(f'    (pad "{pd["name"]}" smd roundrect (at {lx:.3f} {ly:.3f} {rot}) (size 3.0 1.65) (layers "B.Cu" "B.Mask") (roundrect_rratio 0.25){ns} (uuid "{uid()}"))')
            else:
                shape = "rect" if pd["name"] == "1" else "circle"
                L.append(f'    (pad "{pd["name"]}" thru_hole {shape} (at {lx:.3f} {ly:.3f} {rot}) (size 1.7 1.7) (drill 0.9) (layers "*.Cu" "*.Mask"){ns} (uuid "{uid()}"))')
        if k.get("model"):
            off = k.get("model_offset", (0, 0, 0))
            L.append(f'    (model "{M3D}{k["model"]}" (offset (xyz {off[0]:.2f} {off[1]:.2f} {off[2]:.2f})) (scale (xyz 1 1 1)) (rotate (xyz 0 0 0)))')
        L.append('  )')

    # Matriz de perforaciones libres de la placa
    L.append(f'  (footprint "Perfboard:Perforado_2.54mm" (layer "F.Cu") (uuid "{uid()}") (at {X0:.3f} {Y0:.3f})')
    L.append(f'    (property "Reference" "PERF1" (at 0 -3 0) (layer "F.Fab") (hide yes) (uuid "{uid()}") (effects (font (size 1 1) (thickness 0.15))))')
    L.append(f'    (property "Value" "Perfboard" (at 0 -1 0) (layer "F.Fab") (hide yes) (uuid "{uid()}") (effects (font (size 1 1) (thickness 0.15))))')
    L.append('    (attr through_hole exclude_from_pos_files exclude_from_bom)')
    pad_layers = '"*.Cu" "*.Mask"' if board.board_style == "fr4_green" else '"B.Cu" "B.Mask"'
    for c in range(1, board.cols + 1):
        for r in range(1, board.rows + 1):
            if (c, r) in used:
                continue
            x, y = xy(c, r)
            L.append(f'    (pad "" thru_hole circle (at {x - X0:.3f} {y - Y0:.3f}) (size 1.7 1.7) (drill 0.9) (layers {pad_layers}) (uuid "{uid()}"))')
    L.append('  )')

    # Borde y 4 orificios de montaje
    L.append(f'  (gr_rect (start {X0:.3f} {Y0:.3f}) (end {X0 + board.w:.3f} {Y0 + board.h:.3f}) (stroke (width 0.15) (type solid)) (fill none) (layer "Edge.Cuts") (uuid "{uid()}"))')
    for mx_, my_ in [(3.0, 3.0), (board.w - 3.0, 3.0), (3.0, board.h - 3.0), (board.w - 3.0, board.h - 3.0)]:
        L.append(f'  (footprint "MountingHole:MountingHole_2.2mm_M2" (layer "F.Cu") (uuid "{uid()}") (at {X0 + mx_:.3f} {Y0 + my_:.3f})')
        L.append(f'    (property "Reference" "H" (at 0 0 0) (layer "F.Fab") (hide yes) (uuid "{uid()}") (effects (font (size 1 1) (thickness 0.15))))')
        L.append(f'    (property "Value" "M2" (at 0 0 0) (layer "F.Fab") (hide yes) (uuid "{uid()}") (effects (font (size 1 1) (thickness 0.15))))')
        L.append('    (attr exclude_from_pos_files exclude_from_bom)')
        L.append(f'    (pad "" np_thru_hole circle (at 0 0) (size 2.2 2.2) (drill 2.2) (layers "*.Cu" "*.Mask") (uuid "{uid()}"))')
        L.append('  )')

    # Reglas de coordenadas
    for c in sorted(set([1, board.cols] + list(range(5, board.cols + 1, 5)))):
        x, y = xy(c, 1)
        L.append(f'  (gr_text "{c}" (at {x:.3f} {y - 2.2:.3f} 0) (layer "F.SilkS") (uuid "{uid()}") (effects (font (size 0.8 0.8) (thickness 0.12))))')
    for r in sorted(set([1, board.rows] + list(range(5, board.rows + 1, 5)))):
        x, y = xy(1, r)
        L.append(f'  (gr_text "{r}" (at {x - 2.3:.3f} {y:.3f} 0) (layer "F.SilkS") (uuid "{uid()}") (effects (font (size 0.8 0.8) (thickness 0.12))))')

    # Etiquetas de headers / pads de borde
    for comp in board.comps:
        labs = comp["render"].get("labels")
        if not labs:
            continue
        horiz = comp["rot"] in (90, 270)
        for pd, lab in zip(comp["pads"], labs):
            x, y = xy(pd["c"], pd["r"])
            if comp["kind"] == "EDGE14":
                L.append(f'  (gr_text "{lab}" (at {x - 2.2:.3f} {y:.3f} 0) (layer "B.SilkS") (uuid "{uid()}") (effects (font (size 0.8 0.8) (thickness 0.12)) (justify right mirror)))')
            elif horiz:
                dy = -1.7 if pd["r"] > board.rows / 2 else 1.7
                L.append(f'  (gr_text "{lab}" (at {x:.3f} {y + dy:.3f} 90) (layer "F.SilkS") (uuid "{uid()}") (effects (font (size 0.7 0.7) (thickness 0.1)) (justify left)))')
            else:
                L.append(f'  (gr_text "{lab}" (at {x - 1.5:.3f} {y:.3f} 0) (layer "F.SilkS") (uuid "{uid()}") (effects (font (size 0.7 0.7) (thickness 0.1)) (justify right)))')

    # Rieles de cobre/estano en B.Cu
    for net, segs in board.rails.items():
        for a, b_ in segs:
            (x1, y1), (x2, y2) = xy(*a), xy(*b_)
            L.append(f'  (segment (start {x1:.3f} {y1:.3f}) (end {x2:.3f} {y2:.3f}) (width 1.0) (layer "B.Cu") (net {nid[net]}) (uuid "{uid()}"))')

    # Puentes y cables (rutas ortogonales Manhattan)
    for w in board.res["wires"]:
        pts = [xy(c, r) for (c, r) in w["path"]]
        if w["type"] in ("puente", "desnudo", "bridge"):
            for i in range(len(pts) - 1):
                (x1, y1), (x2, y2) = pts[i], pts[i + 1]
                L.append(f'  (segment (start {x1:.3f} {y1:.3f}) (end {x2:.3f} {y2:.3f}) (width 0.8) (layer "B.Cu") (net {nid[w["net"]]}) (uuid "{uid()}"))')
        else:
            lay = "Dwgs.User" if w["type"] == "aislado" else "Eco1.User"
            for i in range(len(pts) - 1):
                (x1, y1), (x2, y2) = pts[i], pts[i + 1]
                L.append(f'  (gr_line (start {x1:.3f} {y1:.3f}) (end {x2:.3f} {y2:.3f}) (stroke (width 0.25) (type solid)) (layer "{lay}") (uuid "{uid()}"))')

    L.append(')')
    with open(os.path.join(OUT, fname), "w", encoding="utf-8") as f:
        f.write("\n".join(L))

def export_csv(board, fname):
    with open(os.path.join(OUT, fname), "w", newline="", encoding="utf-8-sig") as f:
        wr = csv.writer(f, delimiter=";")
        wr.writerow(["#", "Tipo", "Categoria", "Red", "Desde", "Hasta", "Longitud aprox (mm)"])
        for w in board.res["wires"]:
            wr.writerow([
                w["id"], B.TYPE_ES[w["type"]], B.CLASS_ES[w["cls"]], w["net"],
                f'{w["al"]} (C{w["a"][0]},F{w["a"][1]})',
                f'{w["bl"]} (C{w["b"][0]},F{w["b"][1]})',
                w["len_mm"],
            ])

if __name__ == "__main__":
    mar, ram = B.build_mar(), B.build_ram()
    export_kicad(mar, "MAR_7x9.kicad_pcb")
    export_kicad(ram, "RAM_9x15.kicad_pcb")
    export_csv(mar, "cableado_MAR.csv")
    export_csv(ram, "cableado_RAM.csv")
    print("Generados KiCad 9 PCB y CSV correctamente.")
