# -*- coding: utf-8 -*-
"""
Genera modelos 3D reales a escala 1:1 (en milimetros) en formato Wavefront OBJ + MTL:
  * MAR_7x9_3D.obj / .mtl (montaje real PY-7*9 CM verde con pads laterales)
  * RAM_9x15_3D.obj / .mtl (baquelita 9x15 cm, 74LS189, C16/C17 en paralelo + C7)
  * SAP1_MAR_RAM_Ensamble_3D.obj / .mtl (ambas placas + enlace 6 hilos MAR -> RAM)
"""
import math, os
import boards as B

OUT = os.path.dirname(os.path.abspath(__file__))

MATERIALS = {
    "bakelite":   (0.68, 0.41, 0.16, 0.0),
    "fr4_green":  (0.08, 0.48, 0.24, 0.0),
    "copper":     (0.82, 0.52, 0.25, 0.0),
    "solder":     (0.78, 0.80, 0.83, 0.0),
    "socket":     (0.14, 0.14, 0.16, 0.0),
    "ic_body":    (0.08, 0.08, 0.09, 0.0),
    "ic_mark":    (0.75, 0.75, 0.75, 0.0),
    "pin_metal":  (0.84, 0.85, 0.87, 0.0),
    "pin_gold":   (0.88, 0.70, 0.20, 0.0),
    "res_body":   (0.86, 0.76, 0.55, 0.0),
    "res_blue":   (0.16, 0.62, 0.78, 0.0),
    "cap_cer":    (0.88, 0.46, 0.16, 0.0),
    "sip_body":   (0.92, 0.72, 0.16, 0.0),
    "dip_red":    (0.78, 0.12, 0.12, 0.0),
    "dip_black":  (0.12, 0.12, 0.14, 0.0),
    "dip_white":  (0.94, 0.92, 0.82, 0.0),
    "btn_body":   (0.22, 0.22, 0.24, 0.0),
    "btn_cap":    (0.12, 0.12, 0.14, 0.0),
    "sw_metal":   (0.72, 0.74, 0.76, 0.0),
    "hdr_black":  (0.10, 0.10, 0.11, 0.0),
    "led_red":    (0.92, 0.12, 0.12, 0.0),
    "led_green":  (0.12, 0.82, 0.24, 0.0),
    "led_yellow": (0.96, 0.80, 0.08, 0.0),
    "w_gnd":      (0.14, 0.14, 0.14, 0.0),
    "w_vcc":      (0.88, 0.12, 0.12, 0.0),
    "w_bus":      (0.12, 0.44, 0.95, 0.0),
    "w_addr":     (0.94, 0.76, 0.04, 0.0),
    "w_dip":      (0.90, 0.90, 0.90, 0.0),
    "w_led":      (0.62, 0.42, 0.22, 0.0),
    "w_ctrl":     (0.96, 0.48, 0.05, 0.0),
    "w_data":     (0.12, 0.70, 0.30, 0.0),
}


class MeshBuilder:
    def __init__(self):
        self.verts = []
        self.faces = []

    def add_v(self, x, y, z):
        self.verts.append((x, y, z))
        return len(self.verts)

    def box(self, x0, y0, z0, x1, y1, z1, mat):
        xa, xb = min(x0, x1), max(x0, x1)
        ya, yb = min(y0, y1), max(y0, y1)
        za, zb = min(z0, z1), max(z0, z1)
        v = [
            self.add_v(xa, ya, za), self.add_v(xb, ya, za),
            self.add_v(xb, yb, za), self.add_v(xa, yb, za),
            self.add_v(xa, ya, zb), self.add_v(xb, ya, zb),
            self.add_v(xb, yb, zb), self.add_v(xa, yb, zb),
        ]
        for f in [(0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4),
                  (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)]:
            self.faces.append((mat, [v[i] for i in f]))

    def cyl_z(self, cx, cy, z0, z1, r, mat, segs=12):
        bot = [self.add_v(cx + r * math.cos(2 * math.pi * i / segs),
                          cy + r * math.sin(2 * math.pi * i / segs), z0) for i in range(segs)]
        top = [self.add_v(cx + r * math.cos(2 * math.pi * i / segs),
                          cy + r * math.sin(2 * math.pi * i / segs), z1) for i in range(segs)]
        self.faces.append((mat, list(reversed(bot))))
        self.faces.append((mat, top))
        for i in range(segs):
            j = (i + 1) % segs
            self.faces.append((mat, [bot[i], bot[j], top[j], top[i]]))

    def tube(self, pts, r, mat, segs=6):
        rings = []
        for idx, p in enumerate(pts):
            if idx == 0:
                tx, ty, tz = pts[1][0] - p[0], pts[1][1] - p[1], pts[1][2] - p[2]
            elif idx == len(pts) - 1:
                tx, ty, tz = p[0] - pts[-2][0], p[1] - pts[-2][1], p[2] - pts[-2][2]
            else:
                tx = pts[idx + 1][0] - pts[idx - 1][0]
                ty = pts[idx + 1][1] - pts[idx - 1][1]
                tz = pts[idx + 1][2] - pts[idx - 1][2]
            ln = math.sqrt(tx * tx + ty * ty + tz * tz) or 1.0
            tx, ty, tz = tx / ln, ty / ln, tz / ln
            ux, uy, uz = (0.0, 0.0, 1.0) if abs(tz) < 0.9 else (1.0, 0.0, 0.0)
            nx = ty * uz - tz * uy
            ny = tz * ux - tx * uz
            nz = tx * uy - ty * ux
            nl = math.sqrt(nx * nx + ny * ny + nz * nz) or 1.0
            nx, ny, nz = nx / nl, ny / nl, nz / nl
            bx, by, bz = ty * nz - tz * ny, tz * nx - tx * nz, tx * ny - ty * nx
            ring = []
            for s in range(segs):
                a = 2 * math.pi * s / segs
                ca, sa = math.cos(a) * r, math.sin(a) * r
                ring.append(self.add_v(p[0] + ca * nx + sa * bx,
                                       p[1] + ca * ny + sa * by,
                                       p[2] + ca * nz + sa * bz))
            rings.append(ring)
        for k in range(len(rings) - 1):
            r0, r1 = rings[k], rings[k + 1]
            for s in range(segs):
                sn = (s + 1) % segs
                self.faces.append((mat, [r0[s], r0[sn], r1[sn], r1[s]]))

    def save(self, obj_name):
        mtl_name = obj_name.replace(".obj", ".mtl")
        with open(os.path.join(OUT, mtl_name), "w", encoding="utf-8") as fm:
            for name, (r, g, b_, _) in MATERIALS.items():
                fm.write(f"newmtl {name}\nKd {r:.3f} {g:.3f} {b_:.3f}\nKa 0.15 0.15 0.15\nKs 0.25 0.25 0.25\nNs 40\n\n")
        with open(os.path.join(OUT, obj_name), "w", encoding="utf-8") as fo:
            fo.write(f"# SAP-1 Perfboard 3D Model (1 unit = 1 mm)\nmtllib {mtl_name}\n")
            for x, y, z in self.verts:
                fo.write(f"v {x:.3f} {y:.3f} {z:.3f}\n")
            cur = None
            for mat, f in self.faces:
                if mat != cur:
                    fo.write(f"usemtl {mat}\n")
                    cur = mat
                fo.write("f " + " ".join(str(i) for i in f) + "\n")


def add_board_to_mesh(mb, board, ox=0.0, oy=0.0):
    T = 1.6
    def P3(c, r):
        x, y = board.xy(c, r)
        return (ox + x, oy + (board.h - y))

    sub_mat = "fr4_green" if board.board_style == "fr4_green" else "bakelite"
    mb.box(ox, oy, 0.0, ox + board.w, oy + board.h, T, sub_mat)

    occ_pads = {(pd["c"], pd["r"]) for comp in board.comps for pd in comp["pads"]}
    for c in range(1, board.cols + 1):
        for r in range(1, board.rows + 1):
            px, py = P3(c, r)
            rad = 0.85 if (c, r) in occ_pads else 0.72
            mb.box(px - rad, py - rad, -0.06, px + rad, py + rad, 0.0, "copper")
            if board.board_style == "fr4_green":
                mb.box(px - rad, py - rad, T, px + rad, py + rad, T + 0.05, "copper")

    # Pads rectangulares de borde de la placa PY-7*9 CM (ambos bordes izq. y der.)
    if board.board_style == "fr4_green":
        for r in range(2, board.rows):
            for c_edge in (0, board.cols + 1):
                px, py = P3(c_edge, r)
                mb.box(px - 1.5, py - 0.78, -0.07, px + 1.5, py + 0.78, 0.0, "copper")
                mb.box(px - 1.5, py - 0.78, T, px + 1.5, py + 0.78, T + 0.06, "copper")

    for comp in board.comps:
        pts = [P3(p["c"], p["r"]) for p in comp["pads"]]
        xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
        cx, cy = (min(xs) + max(xs)) / 2.0, (min(ys) + max(ys)) / 2.0
        k = comp["kind"]
        if k == "EDGE14":
            # Pads rectangulares estanhados para soldar cables externos
            for px, py in pts:
                mb.box(px - 1.5, py - 0.82, -0.14, px + 1.5, py + 0.82, 0.0, "solder")
            continue

        pmat = "pin_gold" if k.startswith("HDR") else "pin_metal"
        for px, py in pts:
            mb.box(px - 0.25, py - 0.25, -0.8, px + 0.25, py + 0.25, T + 2.0, pmat)

        if k.startswith("DIP"):
            n = int(k[3:])
            l_mm = (n // 2 - 1) * B.P + 2.8
            mb.box(cx - 4.9, cy - l_mm / 2, T, cx + 4.9, cy + l_mm / 2, T + 3.0, "socket")
            mb.box(cx - 3.3, cy - l_mm / 2 + 0.3, T + 3.0, cx + 3.3, cy + l_mm / 2 - 0.3, T + 6.4, "ic_body")
            # Muesca arriba (rot=0) o abajo (rot=180, como en el MAR real!)
            notch_y = (cy - l_mm / 2 + 0.9) if comp["rot"] == 180 else (cy + l_mm / 2 - 0.9)
            mb.cyl_z(cx, notch_y, T + 6.35, T + 6.55, 0.85, "ic_mark", 8)
            p1x, p1y = pts[0]
            dot_x = p1x - 1.6 if comp["rot"] == 180 else p1x + 1.6
            mb.cyl_z(dot_x, p1y, T + 6.35, T + 6.55, 0.55, "ic_mark", 8)
        elif k == "LED5":
            col = comp["render"].get("color", "#ff2b2b")
            lmat = "led_red" if "ff2" in col else ("led_green" if "dd44" in col else "led_yellow")
            mb.cyl_z(cx, cy, T + 1.5, T + 2.6, 2.85, lmat, 12)
            mb.cyl_z(cx, cy, T + 2.6, T + 7.2, 2.5, lmat, 12)
            mb.cyl_z(cx, cy, T + 7.2, T + 8.6, 1.9, lmat, 10)
            mb.cyl_z(cx, cy, T + 8.6, T + 9.3, 1.0, lmat, 8)
        elif k == "R762":
            rmat = "res_blue" if board.board_style == "fr4_green" else "res_body"
            vert = (max(ys) - min(ys)) > (max(xs) - min(xs))
            if vert:
                mb.box(cx - 1.15, cy - 3.1, T + 0.4, cx + 1.15, cy + 3.1, T + 2.7, rmat)
                mb.tube([(pts[0][0], pts[0][1], T + 1.55), (pts[1][0], pts[1][1], T + 1.55)], 0.28, "pin_metal", 5)
            else:
                mb.box(cx - 3.1, cy - 1.15, T + 0.4, cx + 3.1, cy + 1.15, T + 2.7, rmat)
                mb.tube([(pts[0][0], pts[0][1], T + 1.55), (pts[1][0], pts[1][1], T + 1.55)], 0.28, "pin_metal", 5)
        elif k in ("C254", "C508"):
            vert = (max(ys) - min(ys)) > (max(xs) - min(xs))
            rad = 1.8 if k == "C254" else 2.2
            if vert:
                mb.box(cx - 0.9, cy - rad, T + 1.2, cx + 0.9, cy + rad, T + 1.2 + 2 * rad, "cap_cer")
            else:
                mb.box(cx - rad, cy - 0.9, T + 1.2, cx + rad, cy + 0.9, T + 1.2 + 2 * rad, "cap_cer")
        elif k.startswith("SWDIP"):
            n = int(k[5:])
            l_mm = n * B.P + 1.8
            dmat = "dip_black" if "KSPA" in comp["value"] else "dip_red"
            mb.box(cx - l_mm / 2, cy - 4.7, T, cx + l_mm / 2, cy + 4.7, T + 5.8, dmat)
            for i in range(n):
                sx = pts[i][0]
                if "KSPA" in comp["value"]:
                    # Palancas tipo piano saliendo por la parte inferior (como KSPA04-NB real)
                    mb.box(sx - 0.65, cy - 6.2, T + 1.2, sx + 0.65, cy - 4.5, T + 3.4, "dip_white")
                else:
                    mb.box(sx - 0.65, cy - 1.4, T + 5.8, sx + 0.65, cy + 1.0, T + 7.2, "dip_white")
        elif k.startswith("SIP"):
            l_mm = (max(xs) - min(xs)) + 2.0
            mb.box(cx - l_mm / 2, cy - 1.1, T + 0.6, cx + l_mm / 2, cy + 1.1, T + 5.2, "sip_body")
            mb.cyl_z(pts[0][0], cy, T + 5.2, T + 5.4, 0.55, "ic_body", 6)
        elif k == "PUSH6":
            mb.box(cx - 3.0, cy - 3.0, T, cx + 3.0, cy + 3.0, T + 3.6, "btn_body")
            mb.cyl_z(cx, cy, T + 3.6, T + 5.2, 1.75, "btn_cap", 10)
        elif k == "SPDT3":
            mb.box(cx - 2.1, cy - 4.3, T, cx + 2.1, cy + 4.3, T + 4.2, "sw_metal")
            mb.box(cx - 1.1, cy - 0.6, T + 4.2, cx + 1.1, cy + 1.8, T + 7.4, "ic_body")
        elif k.startswith("HDR"):
            horiz = comp["rot"] in (90, 270)
            if horiz:
                mb.box(min(xs) - 1.25, cy - 1.25, T, max(xs) + 1.25, cy + 1.25, T + 2.5, "hdr_black")
            else:
                mb.box(cx - 1.25, min(ys) - 1.25, T, cx + 1.25, max(ys) + 1.25, T + 2.5, "hdr_black")
            for idx, (px, py) in enumerate(pts):
                lab = (comp["render"].get("labels") or [""] * len(pts))[idx]
                if lab == "LLAVE":
                    continue
                mb.box(px - 0.32, py - 0.32, T + 2.5, px + 0.32, py + 0.32, T + 8.5, "pin_gold")

    # Rieles de cobre/estano (cara inferior)
    for net, segs in board.rails.items():
        for a, b_ in segs:
            p1, p2 = P3(*a), P3(*b_)
            mb.tube([(p1[0], p1[1], -0.55), (p2[0], p2[1], -0.55)], 0.55, "solder", 6)

    Z_LAYER = {"gnd": -1.15, "vcc": -1.15, "led": -1.35, "dip": -1.55,
               "data": -1.80, "ctrl": -2.10, "addr": -2.40, "bus": -2.75}
    for idx, w in enumerate(board.res["wires"]):
        p1, p2 = P3(*w["a"]), P3(*w["b"])
        wt = w["type"]
        if wt in ("puente", "bridge"):
            mb.tube([(p1[0], p1[1], -0.45), (p2[0], p2[1], -0.45)], 0.55, "solder", 6)
        elif wt == "desnudo":
            mb.tube([(p1[0], p1[1], -0.60), (p2[0], p2[1], -0.60)], 0.38, "solder", 6)
        elif wt == "potencia":
            z_top = T + 1.2
            mb.tube([(p1[0], p1[1], T), (p1[0], p1[1], z_top), (p2[0], p2[1], z_top), (p2[0], p2[1], T)],
                    0.45, "w_" + w["cls"], 6)
        else:
            z_run = Z_LAYER.get(w["cls"], -2.0) - (idx % 3) * 0.12
            rpts = [P3(c, r) for (c, r) in w["path"]]
            pts_w = [(rpts[0][0], rpts[0][1], -0.35), (rpts[0][0], rpts[0][1], z_run)]
            for i in range(1, len(rpts) - 1):
                pts_w.append((rpts[i][0], rpts[i][1], z_run))
            pts_w.append((rpts[-1][0], rpts[-1][1], z_run))
            pts_w.append((rpts[-1][0], rpts[-1][1], -0.35))
            mb.tube(pts_w, 0.28, "w_" + w["cls"], 5)


if __name__ == "__main__":
    mar, ram = B.build_mar(), B.build_ram()
    for bd, fn in ((mar, "MAR_7x9_3D.obj"), (ram, "RAM_9x15_3D.obj")):
        mb = MeshBuilder()
        add_board_to_mesh(mb, bd)
        mb.save(fn)
        print(f"Generado {fn}: {len(mb.verts)} vertices, {len(mb.faces)} caras")

    # Ensamble MAR arriba + RAM abajo + 6 cables de enlace MAR P_EXT -> RAM J1
    mb_all = MeshBuilder()
    add_board_to_mesh(mb_all, ram, ox=0.0, oy=0.0)
    ox_mar = (ram.w - mar.w) / 2.0
    oy_mar = ram.h + 14.0
    add_board_to_mesh(mb_all, mar, ox=ox_mar, oy=oy_mar)
    p_ext = next(c for c in mar.comps if c["ref"] == "P_EXT")["pads"]
    ram_j1 = next(c for c in ram.comps if c["ref"] == "J1")["pads"]
    # Pares (indice en P_EXT [0-based], indice en RAM J1 [0-based], material)
    links = [(0, 0, "w_gnd"), (13, 1, "w_ctrl"), (9, 2, "w_addr"),
             (10, 3, "w_addr"), (11, 4, "w_addr"), (12, 5, "w_addr")]
    for k, (idx_m, idx_r, mat) in enumerate(links):
        x1, y1 = mar.xy(p_ext[idx_m]["c"], p_ext[idx_m]["r"])
        x2, y2 = ram.xy(ram_j1[idx_r]["c"], ram_j1[idx_r]["r"])
        p1 = (ox_mar + x1, oy_mar + (mar.h - y1), 0.2)
        p2 = (x2, ram.h - y2, 10.0)
        lane_x = -4.5 - k * 1.15
        mb_all.tube([p1, (ox_mar - 4.0 - k * 1.0, p1[1], 4.0),
                     (lane_x, ram.h + 6.0 - k * 0.8, 7.5),
                     (lane_x, p2[1], 10.5), p2], 0.40, mat, 6)
    mb_all.save("SAP1_MAR_RAM_Ensamble_3D.obj")
    print(f"Generado SAP1_MAR_RAM_Ensamble_3D.obj: {len(mb_all.verts)} vertices, {len(mb_all.faces)} caras")
