# -*- coding: utf-8 -*-
"""Genera Visor3D_MAR_RAM.html: visor 3D interactivo (Three.js) optimizado para PC y movil."""
import json, os
import boards as B

OUT = os.path.dirname(os.path.abspath(__file__))

def serialize_board(bd):
    return dict(
        name=bd.name, title=bd.title, w=bd.w, h=bd.h, cols=bd.cols, rows=bd.rows,
        mx=bd.mx, my=bd.my, cmin=bd.cmin, board_style=bd.board_style,
        comps=[dict(ref=c["ref"], kind=c["kind"], value=c["value"], c=c["c"], r=c["r"],
                    rot=c["rot"], desc=c["desc"], new=c["new"], pads=c["pads"],
                    color=c["render"].get("color"), labels=c["render"].get("labels"))
               for c in bd.comps],
        rails=[dict(net=n, cls=B.net_class(n), segs=[[list(a), list(b_)] for a, b_ in segs])
               for n, segs in bd.rails.items()],
        wires=[dict(id=w["id"], net=w["net"], cls=w["cls"], type=w["type"],
                    a=list(w["a"]), b=list(w["b"]), al=w["al"], bl=w["bl"],
                    path=w["path"])
               for w in bd.res["wires"]],
    )

HTML_TEMPLATE = r"""<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no,viewport-fit=cover">
<title>Visor 3D — SAP-1 MAR (7×9 cm) y RAM (9×15 cm)</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
  html,body{width:100%;height:100%;height:100dvh;overflow:hidden;overscroll-behavior:none;background:#10141c;color:#e8edf5;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
  body{position:fixed;inset:0;display:flex;flex-direction:column}

  header{display:flex;flex-wrap:wrap;align-items:center;gap:8px;padding:8px 12px;background:#171d29;border-bottom:1px solid #283246;z-index:30;flex-shrink:0}
  .top-row{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
  h1{font-size:14px;font-weight:700;color:#fff;white-space:nowrap}
  .grp{display:flex;gap:3px;align-items:center;background:#101520;padding:3px;border-radius:8px;border:1px solid #263044}
  button{background:transparent;color:#c2cde0;border:none;padding:6px 10px;border-radius:6px;cursor:pointer;font-size:12px;font-weight:600;transition:.15s;white-space:nowrap;touch-action:manipulation}
  button:hover{background:#232d42;color:#fff}
  button.active{background:#2b6ef2;color:#fff}
  .drawer{display:flex;flex-wrap:wrap;align-items:center;gap:8px}
  .mob-only{display:none}
  label.chk{display:flex;align-items:center;gap:5px;font-size:12px;color:#cdd7e8;padding:4px 8px;cursor:pointer;user-select:none;white-space:nowrap}
  label.chk input{width:15px;height:15px;accent-color:#2b6ef2}
  select{background:#171d29;color:#e8edf5;border:1px solid #2e3b54;border-radius:6px;padding:5px 8px;font-size:12px;max-width:100%}

  #stage{flex:1;position:relative;min-height:0;overflow:hidden;touch-action:none}
  #stage canvas{display:block;width:100%!important;height:100%!important;touch-action:none}

  #info{position:absolute;left:12px;bottom:12px;background:rgba(18,24,36,.93);border:1px solid #2e3b54;border-radius:10px;padding:11px 32px 11px 13px;max-width:340px;font-size:12.5px;line-height:1.45;backdrop-filter:blur(6px);z-index:15}
  #info h3{font-size:13.5px;color:#63a4ff;margin-bottom:4px}
  #infoClose{position:absolute;top:6px;right:6px;padding:2px 7px;font-size:15px;color:#9fb0c9;line-height:1}
  #info.hidden{display:none}

  #legend{position:absolute;right:12px;bottom:12px;background:rgba(18,24,36,.92);border:1px solid #2e3b54;border-radius:10px;padding:10px 12px;font-size:11.5px;line-height:1.6;z-index:15}
  #legend.hidden{display:none}
  .dot{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:6px;vertical-align:middle}
  .badge{display:inline-block;padding:1px 6px;border-radius:4px;font-size:10px;font-weight:700;background:#0d4f5c;color:#5ef2ff;margin-left:5px}

  #mobCamBar{display:none;position:absolute;left:50%;transform:translateX(-50%);bottom:max(10px,env(safe-area-inset-bottom));z-index:14;background:rgba(16,21,32,.92);border:1px solid #2e3b54;border-radius:10px;padding:4px;gap:3px;backdrop-filter:blur(6px)}

  #freeHud{position:absolute;top:10px;left:50%;transform:translateX(-50%);z-index:16;display:flex;flex-wrap:wrap;align-items:center;justify-content:center;gap:8px 12px;background:rgba(16,22,34,.92);border:1px solid #2f5aa8;border-radius:10px;padding:7px 12px;font-size:11.5px;color:#d8e4f8;backdrop-filter:blur(6px);max-width:calc(100% - 20px);box-shadow:0 4px 18px rgba(0,0,0,.35)}
  #freeHud.hidden{display:none}
  #freeHud .fbadge{background:#1b54c6;color:#fff;padding:2px 7px;border-radius:5px;font-weight:700;font-size:11px;letter-spacing:.2px}
  #freeHud kbd{background:#232e44;border:1px solid #3c4d6e;border-radius:4px;padding:1px 5px;font:700 10.5px monospace;color:#8cc0ff}
  #freeHud .spd{display:flex;align-items:center;gap:6px;white-space:nowrap}
  #freeHud input[type=range]{width:86px;accent-color:#4a90ff;cursor:pointer}
  #freeHud #freeSpeedVal{font:700 11px monospace;color:#7ec8ff;min-width:56px;text-align:right}
  #freeHud #btnHudReset{background:#22304a;color:#e8f0ff;padding:3px 8px;font-size:11px;border:1px solid #354b72}
  #freeHud #btnHudReset:hover{background:#2b6ef2;border-color:#2b6ef2}

  #statusOverlay{display:flex;position:absolute;inset:0;align-items:center;justify-content:center;padding:24px;text-align:center;background:#10141c;z-index:40}
  #statusOverlay.hidden{display:none}
  #statusOverlay .card{max-width:480px;background:#192130;border:1px solid #30405c;border-radius:12px;padding:22px;line-height:1.6;font-size:13.5px}

  /* Diseno compacto para telefonos */
  @media (max-width: 780px){
    header{padding:6px 8px;gap:6px}
    .top-row{width:100%;justify-content:space-between;flex-wrap:nowrap}
    h1{display:none}
    .mob-only{display:inline-flex;align-items:center;justify-content:center}
    #modeGrp button{padding:7px 9px;font-size:12px}
    #btnMenu,#btnLegend{background:#101520;border:1px solid #2b3852;padding:7px 10px;font-size:12px;color:#dce6f7}
    #btnMenu.active,#btnLegend.active{background:#2b6ef2;border-color:#2b6ef2;color:#fff}

    .drawer{display:none;width:100%;flex-direction:column;align-items:stretch;gap:6px;padding-top:6px;border-top:1px solid #263044;max-height:52dvh;overflow-y:auto}
    .drawer.open{display:flex}
    .drawer .grp{flex-wrap:wrap;justify-content:space-between;padding:5px}
    #camGrp{display:none}
    label.chk{font-size:13px;padding:6px 8px}
    select{width:100%;padding:8px;font-size:13px}

    #mobCamBar{display:flex}
    #mobCamBar button{padding:7px 11px;font-size:12px}

    #info{left:8px;right:8px;bottom:56px;max-width:none;font-size:12px}
    #legend{right:8px;top:8px;bottom:auto;font-size:11.5px}
  }
</style>
</head>
<body>
<header>
  <div class="top-row">
    <h1>SAP-1 Baquelita 3D</h1>
    <div class="grp" id="modeGrp">
      <button data-mode="BOTH" class="active">MAR+RAM</button>
      <button data-mode="MAR">MAR 7×9</button>
      <button data-mode="RAM">RAM 9×15</button>
    </div>
    <div style="display:flex;gap:5px">
      <button id="btnMenu" class="mob-only" aria-label="Controles">⚙ Capas</button>
      <button id="btnLegend" class="mob-only" aria-label="Colores">●</button>
    </div>
  </div>
  <div class="drawer" id="drawer">
    <div class="grp" id="navModeGrp">
      <button data-nav="orbit" class="active" title="Cámara anclada al centro (tecla C)">Órbita</button>
      <button data-nav="free" title="Cámara Libre Free-Fly para inspección cercana (tecla C)">✈ Libre (C)</button>
      <button id="btnResetCam" title="Restablecer vista inicial (tecla R)">↺ Reset</button>
    </div>
    <div class="grp" id="camGrp">
      <button data-cam="iso">Isométrica</button>
      <button data-cam="top">Arriba</button>
      <button data-cam="bot">Soldadura</button>
      <button data-cam="side">Perfil</button>
    </div>
    <div class="grp">
      <label class="chk"><input type="checkbox" id="tComp" checked> Componentes</label>
      <label class="chk"><input type="checkbox" id="tSolder" checked> Rieles/Estaño</label>
      <label class="chk"><input type="checkbox" id="tWires" checked> Cables AWG30</label>
      <label class="chk"><input type="checkbox" id="tXray"> Rayos X</label>
      <select id="busFilter">
        <option value="ALL">Bus: Todos</option>
        <option value="bus">Solo Bus W (azul)</option>
        <option value="data">Solo Datos internos (verde)</option>
        <option value="addr">Solo Direcciones/PROG (amarillo)</option>
        <option value="dip">Solo Switches DIP (blanco)</option>
        <option value="ctrl">Solo Control/Reloj (naranja)</option>
        <option value="gnd">Solo GND (negro)</option>
      </select>
    </div>
  </div>
</header>

<div id="stage">
  <div id="freeHud" class="hidden">
    <span class="fbadge">✈ CÁMARA LIBRE</span>
    <span><kbd>WASD</kbd>/<kbd>↑↓←→</kbd> Mover · <kbd>E</kbd>/<kbd>Espacio</kbd> Subir · <kbd>Q</kbd>/<kbd>Shift</kbd> Bajar · Arrastrar: Mirar 360° · Rueda: Vel. · <kbd>R</kbd> Reset · <kbd>C</kbd> Órbita</span>
    <span class="spd">Vel: <input type="range" id="freeSpeed" min="4" max="240" step="1" value="55"><span id="freeSpeedVal">55 mm/s</span></span>
    <button id="btnHudReset">↺ Reset</button>
  </div>
  <div id="info">
    <button id="infoClose" title="Cerrar">×</button>
    <h3>Vista 3D Interactiva</h3>
    <div id="infoBody">1 dedo: rotar · 2 dedos: zoom y mover.<br><b>Toca cualquier componente</b> para ver su referencia y coordenadas (C, F).</div>
  </div>
  <div id="legend">
    <div><span class="dot" style="background:#222;border:1px solid #777"></span>GND</div>
    <div><span class="dot" style="background:#e01e1e"></span>VCC (+5V)</div>
    <div><span class="dot" style="background:#1e6fff"></span>Bus W (D0..D7)</div>
    <div><span class="dot" style="background:#f0be00"></span>Direcciones / PROG</div>
    <div><span class="dot" style="background:#ff7b00"></span>Control / Reloj</div>
    <div><span class="dot" style="background:#19b34a"></span>Datos internos</div>
    <div><span class="dot" style="background:#e8e8e8"></span>Switches DIP</div>
    <div><span class="dot" style="background:#a06a38"></span>LEDs</div>
  </div>
  <div id="mobCamBar">
    <button data-cam="iso">Iso</button>
    <button data-cam="top">Arriba</button>
    <button data-cam="bot">Soldadura</button>
    <button data-cam="side">Perfil</button>
  </div>
  <div id="statusOverlay">
    <div class="card" id="statusCard">
      <h2 style="color:#63a4ff;margin-bottom:8px">Cargando visor 3D...</h2>
      <p style="color:#b8c7de">Preparando geometría de MAR y RAM.</p>
    </div>
  </div>
</div>

<script>
const DATA = __DATA_JSON__;
const COLORS = __COLORS_JSON__;
const P = 2.54, T = 1.6;
const isMobile = window.matchMedia('(max-width: 780px)').matches || window.matchMedia('(pointer: coarse)').matches;

function loadScript(src) {
  return new Promise((res, rej) => {
    const s = document.createElement('script');
    s.src = src; s.async = false;
    s.onload = res; s.onerror = rej;
    document.head.appendChild(s);
  });
}

async function loadThree() {
  const cdns = [
    ['https://cdn.jsdelivr.net/npm/three@0.128.0/build/three.min.js',
     'https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.js'],
    ['https://unpkg.com/three@0.128.0/build/three.min.js',
     'https://unpkg.com/three@0.128.0/examples/js/controls/OrbitControls.js']
  ];
  for (const [u1, u2] of cdns) {
    try {
      await loadScript(u1);
      await loadScript(u2);
      if (window.THREE && THREE.OrbitControls) return true;
    } catch (_) {}
  }
  return false;
}

function showError(title, msg) {
  const ov = document.getElementById('statusOverlay');
  ov.classList.remove('hidden');
  document.getElementById('statusCard').innerHTML =
    `<h2 style="color:#ff7b7b;margin-bottom:10px">${title}</h2><p>${msg}</p>`;
}

// UI movil (colapsar paneles por defecto en telefono para dejar 90% de pantalla al 3D)
if (isMobile) {
  document.getElementById('legend').classList.add('hidden');
} else {
  document.getElementById('infoBody').innerHTML =
    'Órbita: arrastra para rotar · rueda para zoom · clic der. para mover.<br>' +
    'Pulsa <b>C</b> para <b>Cámara Libre (WASD/↑↓←→ + E/Q)</b> · <b>R</b> para reiniciar vista.<br>' +
    '<b>Haz clic sobre cualquier componente</b> para ver su referencia y coordenadas (C, F).';
}
document.getElementById('infoClose').onclick = () => document.getElementById('info').classList.add('hidden');
document.getElementById('btnMenu').onclick = function() {
  const d = document.getElementById('drawer');
  const open = d.classList.toggle('open');
  this.classList.toggle('active', open);
};
document.getElementById('btnLegend').onclick = function() {
  const l = document.getElementById('legend');
  const vis = !l.classList.toggle('hidden');
  this.classList.toggle('active', vis);
};

loadThree().then(ok => {
  if (!ok) {
    showError('No se pudo cargar el motor 3D',
      'Si abriste este archivo desde el visor rápido de WhatsApp o del gestor de archivos del teléfono, <b>ábrelo con Google Chrome o Safari</b> (con conexión a Internet).<br><br>' +
      'Para verlo sin conexión en PC o móvil, usa los modelos <b>.obj</b> incluidos en esta carpeta.');
    return;
  }

  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({ antialias: !isMobile, powerPreference: 'high-performance' });
  } catch (e) {
    showError('WebGL no disponible',
      'El visor interno de tu teléfono bloqueó WebGL. Abre <b>Visor3D_MAR_RAM.html</b> directamente en <b>Chrome</b> o <b>Firefox</b>.');
    return;
  }

  document.getElementById('statusOverlay').classList.add('hidden');

  const stage = document.getElementById('stage');
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x10141c);

  const initW = Math.max(1, stage.clientWidth);
  const initH = Math.max(1, stage.clientHeight);
  // Plano near reducido (0.2 mm) para inspeccion milimetrica de pines y cables sin recortes
  const camera = new THREE.PerspectiveCamera(42, initW / initH, 0.2, 900);

  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, isMobile ? 1.5 : 2));
  renderer.setSize(initW, initH, false);
  renderer.shadowMap.enabled = !isMobile;
  if (!isMobile) renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.domElement.style.touchAction = 'none';
  stage.appendChild(renderer.domElement);

  const controls = new THREE.OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = 0.09;
  controls.screenSpacePanning = true;
  controls.maxDistance = 650;
  controls.minDistance = 4;
  controls.touches = { ONE: THREE.TOUCH.ROTATE, TWO: THREE.TOUCH.DOLLY_PAN };

  // Iluminacion limpia de 3 puntos + hemisferio (funciona perfecto arriba y en cara de soldadura sin sombras pesadas)
  scene.add(new THREE.HemisphereLight(0xf6f9ff, 0x3b4860, isMobile ? 0.95 : 0.65));
  const dir1 = new THREE.DirectionalLight(0xfff8ee, isMobile ? 0.85 : 0.95);
  dir1.position.set(120, 180, 110);
  if (!isMobile) {
    dir1.castShadow = true;
    dir1.shadow.mapSize.set(1024, 1024);
    dir1.shadow.camera.left = -160; dir1.shadow.camera.right = 160;
    dir1.shadow.camera.top = 160; dir1.shadow.camera.bottom = -160;
  }
  scene.add(dir1);
  const dir2 = new THREE.DirectionalLight(0x9fc2ff, 0.72);
  dir2.position.set(-100, -150, -80);
  scene.add(dir2);

  const gridHelper = new THREE.GridHelper(320, 32, 0x263145, 0x1a2230);
  gridHelper.position.y = -18;
  scene.add(gridHelper);

  const matCache = {};
  function mat(key, opts) {
    if (!matCache[key]) matCache[key] = new THREE.MeshStandardMaterial(opts);
    return matCache[key];
  }
  const M_BAK = new THREE.MeshStandardMaterial({ color: 0xb06c2b, roughness: 0.72, metalness: 0.05 });
  const M_FR4 = new THREE.MeshStandardMaterial({ color: 0x167842, roughness: 0.52, metalness: 0.08 });
  const M_COP = mat('cop', { color: 0xd48b42, roughness: 0.35, metalness: 0.72 });
  const M_TIN = mat('tin', { color: 0xd6dce2, roughness: 0.28, metalness: 0.85 });
  const M_SOL = mat('sol', { color: 0xd5dade, roughness: 0.28, metalness: 0.82 });
  const M_SOC = mat('soc', { color: 0x23252a, roughness: 0.65 });
  const M_IC  = mat('ic',  { color: 0x141518, roughness: 0.55 });
  const M_PIN = mat('pin', { color: 0xd0d4da, roughness: 0.25, metalness: 0.88 });
  const M_GLD = mat('gld', { color: 0xe2b73b, roughness: 0.25, metalness: 0.88 });
  const M_RES = mat('res', { color: 0xdcc491, roughness: 0.6 });
  const M_RBLU = mat('rblu', { color: 0x289ec7, roughness: 0.48 });
  const M_CER = mat('cer', { color: 0xe0852d, roughness: 0.45 });
  const M_ELC = mat('elc', { color: 0x1a3b82, roughness: 0.35, metalness: 0.2 });
  const M_DIP = mat('dip', { color: 0xc62222, roughness: 0.45 });
  const M_DPB = mat('dpb', { color: 0x1d1f24, roughness: 0.55 });
  const M_MET = mat('met', { color: 0xb8bec6, roughness: 0.32, metalness: 0.82 });
  const M_WHT = mat('wht', { color: 0xf4f4f4, roughness: 0.5 });
  const M_SIP = mat('sip', { color: 0xe6b528, roughness: 0.4 });
  const M_BTN = mat('btn', { color: 0x35383f, roughness: 0.55 });
  const M_HDR = mat('hdr', { color: 0x181a1e, roughness: 0.6 });

  const RAD_SEGS = isMobile ? 4 : 6;
  const CYL_SEGS = isMobile ? 10 : 16;

  function icLabelTexture(ref, val, rot) {
    const cv = document.createElement('canvas'); cv.width = 256; cv.height = 96;
    const g = cv.getContext('2d');
    g.fillStyle = '#15171b'; g.fillRect(0, 0, 256, 96);
    g.fillStyle = '#363d4a'; g.beginPath(); g.arc(10, 48, 18, -Math.PI / 2, Math.PI / 2); g.fill();
    g.fillStyle = '#7e8a9e'; g.beginPath(); g.arc(28, 78, 6, 0, Math.PI * 2); g.fill();
    g.fillStyle = '#d5deec'; g.font = 'bold 26px monospace'; g.textAlign = 'center';
    g.fillText(ref + ' ' + val, 138, 56);
    const tx = new THREE.CanvasTexture(cv);
    tx.center.set(0.5, 0.5);
    tx.rotation = (rot === 180) ? Math.PI / 2 : -Math.PI / 2;
    return tx;
  }

  function makeTube(pts, r, material) {
    const curve = new THREE.CatmullRomCurve3(pts);
    const segs = Math.max(4, pts.length * (isMobile ? 2 : 3));
    return new THREE.Mesh(new THREE.TubeGeometry(curve, segs, r, RAD_SEGS, false), material);
  }

  function makeOrthoTube(pts, r, material) {
    const path = new THREE.CurvePath();
    const smooth = [pts[0]];
    for (let i = 1; i < pts.length - 1; i++) {
      const p0 = pts[i - 1], p1 = pts[i], p2 = pts[i + 1];
      const d1 = p0.distanceTo(p1), d2 = p1.distanceTo(p2);
      const ch = Math.min(0.55, d1 * 0.35, d2 * 0.35);
      if (ch > 0.05) {
        smooth.push(p1.clone().lerp(p0, ch / d1));
        smooth.push(p1.clone().lerp(p2, ch / d2));
      } else {
        smooth.push(p1);
      }
    }
    smooth.push(pts[pts.length - 1]);
    for (let i = 0; i < smooth.length - 1; i++) {
      if (smooth[i].distanceTo(smooth[i + 1]) > 0.02) {
        path.add(new THREE.LineCurve3(smooth[i], smooth[i + 1]));
      }
    }
    const tSegs = Math.max(6, smooth.length * (isMobile ? 2 : 3));
    return new THREE.Mesh(new THREE.TubeGeometry(path, tSegs, r, RAD_SEGS, false), material);
  }

  let pickables = [];
  const root = new THREE.Group();
  scene.add(root);
  let layers = { comp: [], solder: [], wire: [], wireItems: [] };
  let lastCamPreset = 'iso';

  function buildBoard3D(bd, ox, oz) {
    const gBoard = new THREE.Group();
    const gComp = new THREE.Group();
    const gSolder = new THREE.Group();
    const gWire = new THREE.Group();
    gBoard.add(gComp, gSolder, gWire);
    layers.comp.push(gComp); layers.solder.push(gSolder); layers.wire.push(gWire);

    const pos = (c, r) => [ox + bd.mx + (c - 1) * P, oz + bd.my + (r - 1) * P];
    const isFr4 = bd.board_style === 'fr4_green';

    // Sustrato (FR-4 verde doble cara PY-7*9 CM para MAR, baquelita para RAM)
    const slab = new THREE.Mesh(new THREE.BoxGeometry(bd.w, T, bd.h), isFr4 ? M_FR4 : M_BAK);
    slab.position.set(ox + bd.w / 2, T / 2, oz + bd.h / 2);
    if (!isMobile) { slab.receiveShadow = true; slab.castShadow = true; }
    gBoard.add(slab);

    // Pads instanciados (offset limpio -0.10 mm / T+0.08 mm para cero z-fighting en moviles)
    const padGeo = new THREE.CylinderGeometry(0.84, 0.84, 0.14, isMobile ? 8 : 10);
    const padMat = isFr4 ? M_TIN : M_COP;
    const dummy = new THREE.Object3D();
    const padInstBot = new THREE.InstancedMesh(padGeo, padMat, bd.cols * bd.rows);
    let idx = 0;
    for (let c = 1; c <= bd.cols; c++) {
      for (let r = 1; r <= bd.rows; r++) {
        const [px, pz] = pos(c, r);
        dummy.position.set(px, -0.10, pz);
        dummy.updateMatrix();
        padInstBot.setMatrixAt(idx++, dummy.matrix);
      }
    }
    gBoard.add(padInstBot);

    if (isFr4) {
      // Pads superiores + dedos rectangulares de borde (C=0 y C=cols+1) en ambas caras
      const padInstTop = new THREE.InstancedMesh(padGeo, M_TIN, bd.cols * bd.rows);
      idx = 0;
      for (let c = 1; c <= bd.cols; c++) {
        for (let r = 1; r <= bd.rows; r++) {
          const [px, pz] = pos(c, r);
          dummy.position.set(px, T + 0.08, pz);
          dummy.updateMatrix();
          padInstTop.setMatrixAt(idx++, dummy.matrix);
        }
      }
      gBoard.add(padInstTop);

      const fingerGeo = new THREE.BoxGeometry(3.2, 0.14, 1.55);
      const fingerInst = new THREE.InstancedMesh(fingerGeo, M_TIN, bd.rows * 4);
      let fi = 0;
      for (const ec of [0, bd.cols + 1]) {
        for (let r = 1; r <= bd.rows; r++) {
          const [px, pz] = pos(ec, r);
          for (const fy of [-0.10, T + 0.08]) {
            dummy.position.set(px, fy, pz);
            dummy.updateMatrix();
            fingerInst.setMatrixAt(fi++, dummy.matrix);
          }
        }
      }
      gBoard.add(fingerInst);
    }

    // Instanciar todos los pines metalicos (reduce ~250 draw calls a solo 2 en moviles!)
    const metalPins = [], goldPins = [];
    for (const c of bd.comps) {
      if (c.kind === 'EDGE14') continue;
      const target = c.kind.startsWith('HDR') ? goldPins : metalPins;
      for (const p of c.pads) target.push(pos(p.c, p.r));
    }
    const pinGeo = new THREE.BoxGeometry(0.45, T + 2.4, 0.45);
    for (const [arr, mPin] of [[metalPins, M_PIN], [goldPins, M_GLD]]) {
      if (!arr.length) continue;
      const pInst = new THREE.InstancedMesh(pinGeo, mPin, arr.length);
      arr.forEach(([px, pz], i) => {
        dummy.position.set(px, T / 2 + 0.2, pz);
        dummy.updateMatrix();
        pInst.setMatrixAt(i, dummy.matrix);
      });
      gComp.add(pInst);
    }

    // Cuerpos de componentes
    for (const c of bd.comps) {
      const grp = new THREE.Group();
      const pts = c.pads.map(p => pos(p.c, p.r));
      const xs = pts.map(p => p[0]), zs = pts.map(p => p[1]);
      const cx = (Math.min(...xs) + Math.max(...xs)) / 2;
      const cz = (Math.min(...zs) + Math.max(...zs)) / 2;
      const k = c.kind;

      if (k.startsWith('DIP')) {
        const n = parseInt(k.slice(3), 10);
        const len = (n / 2 - 1) * P + 2.8;
        const soc = new THREE.Mesh(new THREE.BoxGeometry(9.6, 3.0, len), M_SOC);
        soc.position.set(cx, T + 1.5, cz); grp.add(soc);
        const topMat = new THREE.MeshStandardMaterial({ map: icLabelTexture(c.ref, c.value, c.rot), roughness: 0.5 });
        const ic = new THREE.Mesh(new THREE.BoxGeometry(6.6, 3.4, len - 0.6), [M_IC, M_IC, topMat, M_IC, M_IC, M_IC]);
        ic.position.set(cx, T + 4.7, cz); grp.add(ic);
      } else if (k === 'LED5') {
        const col = new THREE.Color(c.color || '#ff2b2b');
        const lm = mat('led_' + (c.color || 'r'), { color: col, emissive: col, emissiveIntensity: 0.34, roughness: 0.22, transparent: true, opacity: 0.92 });
        const rim = new THREE.Mesh(new THREE.CylinderGeometry(2.85, 2.85, 1.0, CYL_SEGS), lm);
        rim.position.set(cx, T + 2.2, cz); grp.add(rim);
        const body = new THREE.Mesh(new THREE.CylinderGeometry(2.5, 2.5, 4.6, CYL_SEGS), lm);
        body.position.set(cx, T + 5.0, cz); grp.add(body);
        const dome = new THREE.Mesh(new THREE.SphereGeometry(2.5, CYL_SEGS, 8, 0, Math.PI * 2, 0, Math.PI / 2), lm);
        dome.position.set(cx, T + 7.3, cz); grp.add(dome);
      } else if (k === 'R762') {
        const vert = (Math.max(...zs) - Math.min(...zs)) > (Math.max(...xs) - Math.min(...xs));
        const body = new THREE.Mesh(new THREE.CylinderGeometry(1.15, 1.15, 6.0, 10), isFr4 ? M_RBLU : M_RES);
        body.rotation.x = vert ? Math.PI / 2 : 0;
        body.rotation.z = vert ? 0 : Math.PI / 2;
        body.position.set(cx, T + 1.6, cz); grp.add(body);
        const bar = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.28, 7.62, 6), M_PIN);
        bar.rotation.x = body.rotation.x; bar.rotation.z = body.rotation.z;
        bar.position.set(cx, T + 1.6, cz); grp.add(bar);
      } else if (k === 'C254' || k === 'C508') {
        const vert = (Math.max(...zs) - Math.min(...zs)) > (Math.max(...xs) - Math.min(...xs));
        const rad = k === 'C254' ? 1.7 : 2.3;
        const disc = new THREE.Mesh(new THREE.CylinderGeometry(rad, rad, 1.7, 12), M_CER);
        disc.rotation.z = vert ? Math.PI / 2 : 0;
        disc.rotation.x = vert ? 0 : Math.PI / 2;
        disc.position.set(cx, T + 1.2 + rad, cz); grp.add(disc);
      } else if (k === 'CP5') {
        const cyl = new THREE.Mesh(new THREE.CylinderGeometry(2.5, 2.5, 10.2, CYL_SEGS), M_ELC);
        cyl.position.set(cx, T + 5.3, cz); grp.add(cyl);
        const top = new THREE.Mesh(new THREE.CylinderGeometry(2.2, 2.2, 0.3, CYL_SEGS), M_PIN);
        top.position.set(cx, T + 10.5, cz); grp.add(top);
      } else if (k.startsWith('SWDIP')) {
        const n = parseInt(k.slice(5), 10);
        const isPiano = (c.value || '').indexOf('KSPA') !== -1;
        const body = new THREE.Mesh(new THREE.BoxGeometry(n * P + 1.8, isPiano ? 6.2 : 5.8, 9.4), isPiano ? M_DPB : M_DIP);
        body.position.set(cx, T + (isPiano ? 3.1 : 2.9), cz); grp.add(body);
        for (let i = 0; i < n; i++) {
          if (isPiano) {
            const lv = new THREE.Mesh(new THREE.BoxGeometry(1.25, 1.4, 2.8), M_WHT);
            lv.position.set(pts[i][0], T + 3.4, cz + 5.1); grp.add(lv);
          } else {
            const sl = new THREE.Mesh(new THREE.BoxGeometry(1.2, 1.5, 2.2), M_WHT);
            sl.position.set(pts[i][0], T + 6.5, cz - 0.6); grp.add(sl);
          }
        }
      } else if (k.startsWith('SIP')) {
        const len = (Math.max(...xs) - Math.min(...xs)) + 2.0;
        const body = new THREE.Mesh(new THREE.BoxGeometry(len, 4.6, 2.1), M_SIP);
        body.position.set(cx, T + 2.8, cz); grp.add(body);
      } else if (k === 'PUSH6') {
        const b1 = new THREE.Mesh(new THREE.BoxGeometry(6.0, 3.6, 6.0), M_BTN);
        b1.position.set(cx, T + 1.8, cz); grp.add(b1);
        const cap = new THREE.Mesh(new THREE.CylinderGeometry(1.75, 1.75, 1.8, 12), M_IC);
        cap.position.set(cx, T + 4.4, cz); grp.add(cap);
      } else if (k === 'SPDT3') {
        const b1 = new THREE.Mesh(new THREE.BoxGeometry(4.4, 4.2, 8.6), M_MET);
        b1.position.set(cx, T + 2.1, cz); grp.add(b1);
        const slot = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.5, 5.2), M_SOC);
        slot.position.set(cx, T + 4.25, cz); grp.add(slot);
        const knob = new THREE.Mesh(new THREE.BoxGeometry(2.4, 3.6, 2.4), M_IC);
        knob.position.set(cx, T + 6.0, cz - 1.4); grp.add(knob);
      } else if (k === 'EDGE14') {
        pts.forEach(([px, pz]) => {
          const tPad = new THREE.Mesh(new THREE.BoxGeometry(3.5, 0.24, 1.72), M_GLD);
          tPad.position.set(px, T + 0.14, pz); grp.add(tPad);
          const bPad = new THREE.Mesh(new THREE.BoxGeometry(3.5, 0.24, 1.72), M_GLD);
          bPad.position.set(px, -0.18, pz); grp.add(bPad);
        });
      } else if (k === 'LOCK6') {
        const b1 = new THREE.Mesh(new THREE.BoxGeometry(8.0, 7.5, 8.0), M_BTN);
        b1.position.set(cx, T + 3.75, cz); grp.add(b1);
        const cap = new THREE.Mesh(new THREE.BoxGeometry(4.8, 3.6, 4.8), M_DIP);
        cap.position.set(cx, T + 9.2, cz); grp.add(cap);
      } else if (k.startsWith('HDR')) {
        const horiz = c.rot === 90 || c.rot === 270;
        const sx = horiz ? (Math.max(...xs) - Math.min(...xs)) + 2.5 : 2.5;
        const sz = horiz ? 2.5 : (Math.max(...zs) - Math.min(...zs)) + 2.5;
        const base = new THREE.Mesh(new THREE.BoxGeometry(sx, 2.5, sz), M_HDR);
        base.position.set(cx, T + 1.25, cz); grp.add(base);
        pts.forEach(([px, pz], i) => {
          if (c.labels && c.labels[i] === 'LLAVE') return;
          const pin = new THREE.Mesh(new THREE.BoxGeometry(0.62, 6.2, 0.62), M_GLD);
          pin.position.set(px, T + 5.5, pz); grp.add(pin);
        });
      }

      grp.traverse(obj => {
        if (obj.isMesh) {
          if (!isMobile) obj.castShadow = true;
          obj.userData = { board: bd.name, comp: c };
          pickables.push(obj);
        }
      });
      gComp.add(grp);
    }

    // Rieles de cobre/estano (cara inferior)
    for (const rl of bd.rails) {
      for (const [a, b] of rl.segs) {
        const [x1, z1] = pos(a[0], a[1]), [x2, z2] = pos(b[0], b[1]);
        gSolder.add(makeTube([new THREE.Vector3(x1, -0.55, z1), new THREE.Vector3(x2, -0.55, z2)], 0.55, M_SOL));
      }
    }

    // Puentes y cables (ortogonales Manhattan estratificados en Z)
    const Z_LAY = { gnd: -1.10, vcc: -1.10, led: -1.35, dip: -1.60, data: -1.85, ctrl: -2.15, addr: -2.45, bus: -2.80 };
    bd.wires.forEach((w, i) => {
      const [x1, z1] = pos(w.a[0], w.a[1]), [x2, z2] = pos(w.b[0], w.b[1]);
      if (w.type === 'puente' || w.type === 'bridge') {
        gSolder.add(makeTube([new THREE.Vector3(x1, -0.45, z1), new THREE.Vector3(x2, -0.45, z2)], 0.55, M_SOL));
      } else if (w.type === 'desnudo') {
        gSolder.add(makeTube([new THREE.Vector3(x1, -0.60, z1), new THREE.Vector3(x2, -0.60, z2)], 0.36, M_SOL));
      } else if (w.type === 'potencia') {
        const wm = mat('w_' + w.cls, { color: COLORS[w.cls], roughness: 0.45 });
        const m = makeOrthoTube([
          new THREE.Vector3(x1, T, z1), new THREE.Vector3(x1, T + 1.2, z1),
          new THREE.Vector3(x2, T + 1.2, z2), new THREE.Vector3(x2, T, z2)
        ], 0.42, wm);
        gWire.add(m);
        layers.wireItems.push({ mesh: m, cls: w.cls });
      } else {
        const wm = mat('w_' + w.cls, { color: COLORS[w.cls], roughness: 0.45 });
        const yRun = (Z_LAY[w.cls] || -2.0) - (i % 3) * 0.12;
        const rpts = w.path.map(pt => pos(pt[0], pt[1]));
        const v3 = [new THREE.Vector3(rpts[0][0], -0.35, rpts[0][1])];
        for (const [rx, rz] of rpts) v3.push(new THREE.Vector3(rx, yRun, rz));
        v3.push(new THREE.Vector3(rpts[rpts.length - 1][0], -0.35, rpts[rpts.length - 1][1]));
        const m = makeOrthoTube(v3, 0.27, wm);
        gWire.add(m);
        layers.wireItems.push({ mesh: m, cls: w.cls });
      }
    });

    return gBoard;
  }

  let currentMode = 'BOTH';
  function rebuild(mode) {
    currentMode = mode;
    while (root.children.length) root.remove(root.children[0]);
    pickables = [];
    layers = { comp: [], solder: [], wire: [], wireItems: [] };

    if (mode === 'MAR') {
      root.add(buildBoard3D(DATA.MAR, -DATA.MAR.w / 2, -DATA.MAR.h / 2));
    } else if (mode === 'RAM') {
      root.add(buildBoard3D(DATA.RAM, -DATA.RAM.w / 2, -DATA.RAM.h / 2));
    } else {
      const ramOx = -DATA.RAM.w / 2, ramOz = 7;
      const marOx = -DATA.MAR.w / 2, marOz = -DATA.MAR.h - 7;
      root.add(buildBoard3D(DATA.MAR, marOx, marOz));
      root.add(buildBoard3D(DATA.RAM, ramOx, ramOz));
      const marExt = DATA.MAR.comps.find(c => c.ref === 'P_EXT').pads;
      const ramJ1 = DATA.RAM.comps.find(c => c.ref === 'J1').pads;
      // Mapeo MAR P_EXT (0:GND, 13:PROG, 9:A3, 10:A2, 11:A1, 12:A0) -> RAM J1 (0..5)
      const links = [
        [0, 0, '#222222'], [13, 1, '#ff7b00'],
        [9, 2, '#f0be00'], [10, 3, '#f0be00'], [11, 4, '#f0be00'], [12, 5, '#f0be00']
      ];
      const gRib = new THREE.Group();
      links.forEach(([im, ir, col], k) => {
        const x1 = marOx + DATA.MAR.mx + (marExt[im].c - 1) * P;
        const z1 = marOz + DATA.MAR.my + (marExt[im].r - 1) * P;
        const x2 = ramOx + DATA.RAM.mx + (ramJ1[ir].c - 1) * P;
        const z2 = ramOz + DATA.RAM.my + (ramJ1[ir].r - 1) * P;
        const outX = ramOx - 4.5 - k * 1.15;
        const gapZ = -2.5 + k * 0.85;
        const m = mat('rib_' + k, { color: col, roughness: 0.45 });
        gRib.add(makeTube([
          new THREE.Vector3(x1, 0.3, z1),
          new THREE.Vector3(marOx - 4.0 - k * 1.0, 3.2, z1),
          new THREE.Vector3(outX, 6.8, gapZ),
          new THREE.Vector3(outX, 9.5, z2),
          new THREE.Vector3(x2, 9.5, z2),
        ], 0.40, m));
      });
      root.add(gRib);
      layers.wire.push(gRib);
    }
    applyToggles();
    setCam('iso');
  }

  function applyToggles() {
    const vC = document.getElementById('tComp').checked;
    const vS = document.getElementById('tSolder').checked;
    const vW = document.getElementById('tWires').checked;
    const xr = document.getElementById('tXray').checked;
    const bf = document.getElementById('busFilter').value;
    layers.comp.forEach(g => g.visible = vC);
    layers.solder.forEach(g => g.visible = vS);
    layers.wire.forEach(g => g.visible = vW);
    layers.wireItems.forEach(it => it.mesh.visible = vW && (bf === 'ALL' || it.cls === bf));
    [M_BAK, M_FR4].forEach(m => { m.transparent = xr; m.opacity = xr ? 0.32 : 1.0; m.needsUpdate = true; });
  }

  // ---- Modo de Camara: Orbita vs Camara Libre (Free-Fly) ----
  let navMode = 'orbit';
  let freeYaw = 0, freePitch = 0, freeSpeed = 55;
  const keys = Object.create(null);
  let isLooking = false, lookPtrId = null, lookLastX = 0, lookLastY = 0;
  const _fwd = new THREE.Vector3(), _right = new THREE.Vector3();
  const _worldUp = new THREE.Vector3(0, 1, 0), _move = new THREE.Vector3();
  const _euler = new THREE.Euler(0, 0, 0, 'YXZ');

  const freeHud = document.getElementById('freeHud');
  const speedSlider = document.getElementById('freeSpeed');
  const speedVal = document.getElementById('freeSpeedVal');

  function setFreeSpeed(v) {
    freeSpeed = Math.round(Math.max(4, Math.min(240, v)));
    speedSlider.value = String(freeSpeed);
    speedVal.textContent = freeSpeed + ' mm/s';
  }
  speedSlider.oninput = () => setFreeSpeed(parseFloat(speedSlider.value));
  speedSlider.onchange = () => speedSlider.blur();

  function syncFreeAnglesFromCamera() {
    _euler.setFromQuaternion(camera.quaternion, 'YXZ');
    freeYaw = _euler.y;
    freePitch = Math.max(-1.55, Math.min(1.55, _euler.x));
  }
  function applyFreeAngles() {
    _euler.set(freePitch, freeYaw, 0, 'YXZ');
    camera.quaternion.setFromEuler(_euler);
  }
  function clearKeys() { for (const k in keys) delete keys[k]; }

  function setNavMode(mode) {
    if (mode === navMode) return;
    navMode = mode;
    clearKeys();
    isLooking = false; lookPtrId = null;
    document.querySelectorAll('#navModeGrp button[data-nav]').forEach(b => {
      b.classList.toggle('active', b.dataset.nav === mode);
    });
    freeHud.classList.toggle('hidden', mode !== 'free');
    renderer.domElement.style.cursor = mode === 'free' ? 'grab' : '';
    if (mode === 'free') {
      controls.enabled = false;
      syncFreeAnglesFromCamera();
    } else {
      camera.getWorldDirection(_fwd);
      let dist = 70;
      if (Math.abs(_fwd.y) > 0.05) {
        const t = -camera.position.y / _fwd.y;
        if (t > 8 && t < 240) dist = t;
      }
      controls.target.copy(camera.position).addScaledVector(_fwd, dist);
      controls.enabled = true;
      controls.update();
    }
  }

  function setCam(preset) {
    lastCamPreset = preset;
    const aspect = Math.max(0.42, stage.clientWidth / Math.max(1, stage.clientHeight));
    // Compensacion automatica de encuadre para telefonos en vertical (aspect < 1)
    const portraitBoost = aspect < 1 ? (1.0 / aspect) * 0.78 : 1.0;
    const baseDist = currentMode === 'MAR' ? 125 : (currentMode === 'RAM' ? 185 : 225);
    const dist = baseDist * Math.max(1.0, portraitBoost);
    controls.target.set(0, 0, currentMode === 'BOTH' ? 8 : 0);
    if (preset === 'iso') camera.position.set(dist * 0.40, dist * 0.74, dist * 0.72);
    if (preset === 'top') camera.position.set(0, dist * 1.05, 0.01);
    if (preset === 'bot') camera.position.set(0, -dist * 1.05, 0.01);
    if (preset === 'side') camera.position.set(dist * 0.95, dist * 0.25, 0);
    if (navMode === 'free') {
      camera.lookAt(controls.target);
      syncFreeAnglesFromCamera();
    } else {
      controls.update();
    }
  }

  document.querySelectorAll('#modeGrp button').forEach(btn => btn.onclick = () => {
    document.querySelectorAll('#modeGrp button').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    btn.blur();
    rebuild(btn.dataset.mode);
  });
  document.querySelectorAll('#navModeGrp button[data-nav]').forEach(btn => btn.onclick = () => {
    btn.blur();
    setNavMode(btn.dataset.nav);
  });
  document.getElementById('btnResetCam').onclick = function() { this.blur(); setCam('iso'); };
  document.getElementById('btnHudReset').onclick = function() { this.blur(); setCam('iso'); };
  document.querySelectorAll('[data-cam]').forEach(btn => btn.onclick = () => { btn.blur(); setCam(btn.dataset.cam); });
  ['tComp', 'tSolder', 'tWires', 'tXray', 'busFilter'].forEach(id => {
    const el = document.getElementById(id);
    el.onchange = () => { applyToggles(); el.blur(); };
  });

  // Atajos de teclado globales (C = alternar modo, R = reset, WASD/Flechas/E/Q/Espacio/Shift = mover)
  const FREE_KEYS = new Set([
    'KeyW', 'KeyA', 'KeyS', 'KeyD', 'KeyE', 'KeyQ',
    'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight',
    'Space', 'ShiftLeft', 'ShiftRight'
  ]);
  window.addEventListener('keydown', ev => {
    if (ev.ctrlKey || ev.metaKey || ev.altKey) return;
    if (ev.code === 'KeyC' && !ev.repeat) {
      ev.preventDefault();
      setNavMode(navMode === 'orbit' ? 'free' : 'orbit');
      return;
    }
    if (ev.code === 'KeyR' && !ev.repeat) {
      ev.preventDefault();
      setCam('iso');
      return;
    }
    if (navMode === 'free' && FREE_KEYS.has(ev.code)) {
      ev.preventDefault();
      keys[ev.code] = true;
    }
  });
  window.addEventListener('keyup', ev => {
    if (FREE_KEYS.has(ev.code)) delete keys[ev.code];
  });
  window.addEventListener('blur', clearKeys);

  // Rueda del raton en Modo Libre ajusta velocidad de desplazamiento
  renderer.domElement.addEventListener('wheel', ev => {
    if (navMode !== 'free') return;
    ev.preventDefault();
    setFreeSpeed(freeSpeed * (ev.deltaY < 0 ? 1.18 : 1 / 1.18));
  }, { passive: false });
  renderer.domElement.addEventListener('contextmenu', ev => ev.preventDefault());

  // Deteccion de toque/clic vs arrastre (y rotacion 360° en Modo Camara Libre)
  const ray = new THREE.Raycaster(), mouse = new THREE.Vector2();
  let downPos = null, activePointers = 0;
  renderer.domElement.addEventListener('pointerdown', ev => {
    activePointers++;
    downPos = activePointers === 1 ? { x: ev.clientX, y: ev.clientY, t: Date.now(), btn: ev.button } : null;
    if (navMode === 'free' && activePointers === 1 && (ev.button === 0 || ev.button === 2 || ev.pointerType === 'touch')) {
      isLooking = true;
      lookPtrId = ev.pointerId;
      lookLastX = ev.clientX;
      lookLastY = ev.clientY;
      renderer.domElement.style.cursor = 'grabbing';
      try { renderer.domElement.setPointerCapture(ev.pointerId); } catch (_) {}
    }
  });
  renderer.domElement.addEventListener('pointermove', ev => {
    if (!isLooking || navMode !== 'free' || ev.pointerId !== lookPtrId) return;
    const dx = ev.clientX - lookLastX;
    const dy = ev.clientY - lookLastY;
    lookLastX = ev.clientX;
    lookLastY = ev.clientY;
    freeYaw -= dx * 0.0042;
    freePitch = Math.max(-1.55, Math.min(1.55, freePitch - dy * 0.0042));
    applyFreeAngles();
  });
  function stopLook(ev) {
    if (isLooking && (!ev || ev.pointerId === lookPtrId)) {
      isLooking = false;
      try { if (lookPtrId !== null) renderer.domElement.releasePointerCapture(lookPtrId); } catch (_) {}
      lookPtrId = null;
      if (navMode === 'free') renderer.domElement.style.cursor = 'grab';
    }
  }
  renderer.domElement.addEventListener('pointercancel', ev => { activePointers = 0; downPos = null; stopLook(ev); });
  renderer.domElement.addEventListener('pointerup', ev => {
    activePointers = Math.max(0, activePointers - 1);
    stopLook(ev);
    if (!downPos || activePointers > 0) return;
    const moved = Math.hypot(ev.clientX - downPos.x, ev.clientY - downPos.y);
    const dt = Date.now() - downPos.t;
    const btn = downPos.btn;
    downPos = null;
    if (btn === 2 || moved > 8 || dt > 450) return;
    const rect = renderer.domElement.getBoundingClientRect();
    mouse.x = ((ev.clientX - rect.left) / rect.width) * 2 - 1;
    mouse.y = -((ev.clientY - rect.top) / rect.height) * 2 + 1;
    ray.setFromCamera(mouse, camera);
    const hits = ray.intersectObjects(pickables, false);
    if (!hits.length) return;
    const { board, comp } = hits[0].object.userData;
    const p1 = comp.pads[0];
    const badge = comp.new ? '<span class="badge">MEJORA</span>' : '';
    const labs = comp.labels ? `<br><b>Pines:</b> ${comp.labels.map((l, i) => `${i + 1}:${l}`).join(' · ')}` : '';
    const info = document.getElementById('info');
    info.classList.remove('hidden');
    info.querySelector('h3').innerHTML = `[${board}] ${comp.ref} — ${comp.value}${badge}`;
    document.getElementById('infoBody').innerHTML =
      `<b>Pin 1:</b> Columna ${p1.c}, Fila ${p1.r} · <b>Rot.:</b> ${comp.rot}°<br><b>Función:</b> ${comp.desc}${labs}`;
  });

  // ResizeObserver mantiene el canvas siempre nitido al girar el telefono o abrir el menu
  function syncSize() {
    const w = Math.max(1, stage.clientWidth);
    const h = Math.max(1, stage.clientHeight);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h, false);
  }
  if (typeof ResizeObserver !== 'undefined') {
    new ResizeObserver(syncSize).observe(stage);
  } else {
    window.addEventListener('resize', syncSize);
  }
  window.addEventListener('orientationchange', () => setTimeout(() => { syncSize(); setCam(lastCamPreset); }, 180));

  renderer.domElement.addEventListener('webglcontextlost', ev => {
    ev.preventDefault();
    showError('Contexto 3D pausado', 'Recarga la página para restaurar el visor 3D.');
  });

  rebuild('BOTH');
  let lastT = performance.now();
  (function loop(now) {
    requestAnimationFrame(loop);
    const dt = Math.min(0.05, Math.max(0.001, ((now || performance.now()) - lastT) / 1000));
    lastT = now || performance.now();
    if (navMode === 'free') {
      camera.getWorldDirection(_fwd);
      _right.crossVectors(_fwd, _worldUp);
      if (_right.lengthSq() > 1e-6) _right.normalize();
      else _right.set(1, 0, 0);
      _move.set(0, 0, 0);
      if (keys.KeyW || keys.ArrowUp) _move.add(_fwd);
      if (keys.KeyS || keys.ArrowDown) _move.sub(_fwd);
      if (keys.KeyD || keys.ArrowRight) _move.add(_right);
      if (keys.KeyA || keys.ArrowLeft) _move.sub(_right);
      if (keys.KeyE || keys.Space) _move.add(_worldUp);
      if (keys.KeyQ || keys.ShiftLeft || keys.ShiftRight) _move.sub(_worldUp);
      if (_move.lengthSq() > 0) {
        _move.normalize().multiplyScalar(freeSpeed * dt);
        camera.position.add(_move);
      }
    } else {
      controls.update();
    }
    renderer.render(scene, camera);
  })(lastT);
});
</script>
</body>
</html>
"""

if __name__ == "__main__":
    mar, ram = B.build_mar(), B.build_ram()
    payload = dict(MAR=serialize_board(mar), RAM=serialize_board(ram))
    html_out = HTML_TEMPLATE.replace("__DATA_JSON__", json.dumps(payload, ensure_ascii=False))
    html_out = html_out.replace("__COLORS_JSON__", json.dumps(B.COLORS))
    with open(os.path.join(OUT, "Visor3D_MAR_RAM.html"), "w", encoding="utf-8") as f:
        f.write(html_out)
    print("Generado Visor3D_MAR_RAM.html (version PC + movil) correctamente.")
