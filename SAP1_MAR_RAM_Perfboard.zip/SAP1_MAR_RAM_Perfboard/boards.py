# -*- coding: utf-8 -*-
"""
Fuente unica de verdad + enrutador ortogonal Manhattan (rejilla 1.27 mm)
para los modulos MAR (7x9 cm, montaje real PY-7*9 CM) y RAM (9x15 cm, 74LS189)
de la computadora SAP-1 en placa perforada paso 2.54 mm.

Coordenadas (C, F) = (Columna, Fila), base 1, vistas desde la CARA DE COMPONENTES
con origen arriba-izquierda. En el MAR, C=0 representa los pads rectangulares
del borde lateral (izquierda en cara componentes / derecha en cara soldadura espejada).
"""
import heapq, math

P = 2.54  # paso estandar 0.1"

def dip_local(n):
    return [(str(i), 0.0, (i - 1) * P) if i <= n // 2 else (str(i), 7.62, (n - i) * P)
            for i in range(1, n + 1)]

def swdip_local(n):
    return [(str(i), 0.0, (i - 1) * P) if i <= n else (str(i), 7.62, (2 * n - i) * P)
            for i in range(1, 2 * n + 1)]

def row_local(n):
    return [(str(i), 0.0, (i - 1) * P) for i in range(1, n + 1)]

def sip_local(n):
    return [(str(i), (i - 1) * P, 0.0) for i in range(1, n + 1)]

# Pads rectangulares de borde del MAR real (filas relativas a F=3: 3,5,6,7,8,9,10,11,13,15,16,17,18,20)
MAR_EDGE_ROWS = [3, 5, 6, 7, 8, 9, 10, 11, 13, 15, 16, 17, 18, 20]
MAR_EDGE_LABELS = ["GND", "CLR", "CLK", "~MI", "BUS_0", "BUS_1", "BUS_2", "BUS_3",
                   "VCC", "A3", "A2", "A1", "A0", "PROG"]

KINDS = {
    "DIP14": dict(local=dip_local(14), fp="Package_DIP:DIP-14_W7.62mm",
                  model="Package_DIP.3dshapes/DIP-14_W7.62mm.wrl"),
    "DIP16": dict(local=dip_local(16), fp="Package_DIP:DIP-16_W7.62mm",
                  model="Package_DIP.3dshapes/DIP-16_W7.62mm.wrl"),
    "DIP20": dict(local=dip_local(20), fp="Package_DIP:DIP-20_W7.62mm",
                  model="Package_DIP.3dshapes/DIP-20_W7.62mm.wrl"),
    "LED5": dict(local=[("1", 0, 0), ("2", P, 0)], fp="LED_THT:LED_D5.0mm",
                 model="LED_THT.3dshapes/LED_D5.0mm.wrl"),
    "R762": dict(local=[("1", 0, 0), ("2", 7.62, 0)],
                 fp="Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal",
                 model="Resistor_THT.3dshapes/R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal.wrl"),
    "C254": dict(local=[("1", 0, 0), ("2", P, 0)],
                 fp="Capacitor_THT:C_Disc_D3.0mm_W1.6mm_P2.50mm",
                 model="Capacitor_THT.3dshapes/C_Disc_D3.0mm_W1.6mm_P2.50mm.wrl"),
    "C508": dict(local=[("1", 0, 0), ("2", 2 * P, 0)],
                 fp="Capacitor_THT:C_Disc_D4.3mm_W1.9mm_P5.00mm",
                 model="Capacitor_THT.3dshapes/C_Disc_D4.3mm_W1.9mm_P5.00mm.wrl"),
    "SWDIP4": dict(local=swdip_local(4),
                   fp="Button_Switch_THT:SW_DIP_SPSTx04_Slide_9.78x12.34mm_W7.62mm_P2.54mm",
                   model="Button_Switch_THT.3dshapes/SW_DIP_SPSTx04_Slide_9.78x12.34mm_W7.62mm_P2.54mm.wrl"),
    "SWDIP8": dict(local=swdip_local(8),
                   fp="Button_Switch_THT:SW_DIP_SPSTx08_Slide_9.78x22.5mm_W7.62mm_P2.54mm",
                   model="Button_Switch_THT.3dshapes/SW_DIP_SPSTx08_Slide_9.78x22.5mm_W7.62mm_P2.54mm.wrl"),
    "SIP9": dict(local=sip_local(9), fp="Resistor_THT:R_Array_SIP9",
                 model="Resistor_THT.3dshapes/R_Array_SIP9.wrl"),
    "PUSH6": dict(local=[("1", 0, 0), ("1", 3 * P, 0), ("2", 0, 2 * P), ("2", 3 * P, 2 * P)],
                  fp="Button_Switch_THT:SW_PUSH_6mm_H5mm",
                  model="Button_Switch_THT.3dshapes/SW_PUSH_6mm_H5mm.wrl",
                  model_offset=(0.56, -0.29, 0)),
    "SPDT3": dict(local=[("1", 0, 0), ("2", 0, P), ("3", 0, 2 * P)],
                  fp="Button_Switch_THT:SW_Slide_1P2T_CK_OS102011MS2Q",
                  model="Button_Switch_THT.3dshapes/SW_Slide_1P2T_CK_OS102011MS2Q.wrl"),
    "EDGE14": dict(local=[(str(i + 1), 0.0, (r - MAR_EDGE_ROWS[0]) * P) for i, r in enumerate(MAR_EDGE_ROWS)],
                   fp="Connector_PinHeader_2.54mm:PinHeader_1x14_P2.54mm_Vertical",
                   model=None),
}
for _n in (6, 16):
    KINDS["HDR%d" % _n] = dict(
        local=row_local(_n),
        fp="Connector_PinHeader_2.54mm:PinHeader_1x%02d_P2.54mm_Vertical" % _n,
        model="Connector_PinHeader_2.54mm.3dshapes/PinHeader_1x%02d_P2.54mm_Vertical.wrl" % _n,
    )

COLORS = dict(
    gnd="#222222", vcc="#e01e1e", bus="#1e6fff", addr="#f0be00",
    dip="#e8e8e8", led="#a06a38", ctrl="#ff7b00", data="#19b34a",
)
CLASS_ES = dict(
    gnd="GND (negro)", vcc="VCC +5V (rojo)", bus="Bus W (azul)",
    addr="Direcciones / PROG (amarillo)", dip="Switches DIP (blanco)",
    led="LEDs (marron)", ctrl="Control / Reloj (naranja)",
    data="Datos internos (verde)",
)
TYPE_ES = {
    "puente": "Puente de estano (pads adyacentes)",
    "bridge": "Puente de estano (pads adyacentes)",
    "desnudo": "Alambre desnudo recto (cara soldadura)",
    "aislado": "Cable aislado AWG 28-30 (Kynar, ortogonal)",
    "potencia": "Puente potencia aislado AWG 22 (cara comp.)",
}

def rotate(x, y, a):
    r = math.radians(a)
    return (x * math.cos(r) + y * math.sin(r), -x * math.sin(r) + y * math.cos(r))

def seg_holes(a, b):
    (c1, r1), (c2, r2) = a, b
    if c1 == c2:
        return [(c1, r) for r in range(min(r1, r2), max(r1, r2) + 1)]
    if r1 == r2:
        return [(c, r1) for c in range(min(c1, c2), max(c1, c2) + 1)]
    raise ValueError("Segmento no ortogonal: %s -> %s" % (a, b))

def net_class(net):
    if net == "GND": return "gnd"
    if net == "VCC": return "vcc"
    if net.startswith("BUS_"): return "bus"
    if net in ("A0", "A1", "A2", "A3", "PROG"): return "addr"
    if net.startswith("SW_"): return "dip"
    if net.startswith("LED") or net == "RUN_K": return "led"
    if net in ("CLK", "CLR", "~MI", "RI", "~RO", "~WE", "PULSO", "WR_BTN", "WE_RUN"):
        return "ctrl"
    return "data"

class Board:
    def __init__(self, name, title, w_mm, h_mm, cols, rows, cmin=1, board_style="bakelite"):
        self.name, self.title = name, title
        self.w, self.h = float(w_mm), float(h_mm)
        self.cols, self.rows = cols, rows
        self.cmin = cmin  # 0 cuando hay pads de borde laterales (MAR PY-7*9)
        self.board_style = board_style
        self.mx = (self.w - (cols - 1) * P) / 2.0
        self.my = (self.h - (rows - 1) * P) / 2.0
        self.comps, self.nets, self.rails, self.extra, self.notes = [], {}, {}, [], {}
        self.nc = set()
        self.res = None

    def xy(self, c, r):
        return (self.mx + (c - 1) * P, self.my + (r - 1) * P)

    def add(self, ref, kind, value, c, r, rot=0, desc="", new=False, **render):
        k = KINDS[kind]
        pads = []
        for (pname, x, y) in k["local"]:
            dx, dy = rotate(x, y, rot)
            pads.append(dict(name=pname, c=c + int(round(dx / P)), r=r + int(round(dy / P))))
        self.comps.append(dict(ref=ref, kind=kind, value=value, c=c, r=r, rot=rot,
                               pads=pads, desc=desc, new=new, render=render))

    def net(self, name, *pins):
        self.nets.setdefault(name, []).extend(pins)

    def rail(self, net, *segs):
        self.rails.setdefault(net, []).extend(segs)


# ----------------------------------------------------------------------------
# Enrutador Manhattan A* en rejilla de medio paso (0.5 pad = 1.27 mm)
# ----------------------------------------------------------------------------
def simplify_path(pts):
    if len(pts) <= 2:
        return pts
    out = [pts[0]]
    for i in range(1, len(pts) - 1):
        p0, p1, p2 = out[-1], pts[i], pts[i + 1]
        if (p0[0] == p1[0] == p2[0]) or (p0[1] == p1[1] == p2[1]):
            continue
        out.append(p1)
    out.append(pts[-1])
    return out

def route_manhattan(board, wires, occ):
    xmin, xmax = 2 * board.cmin, 2 * board.cols
    ymin, ymax = 2, 2 * board.rows

    pad_nodes = set((2 * c, 2 * r) for (c, r) in occ.keys())
    rail_edges = set()
    for segs in board.rails.values():
        for a, b_ in segs:
            hs = seg_holes(a, b_)
            for i in range(len(hs) - 1):
                u = (2 * hs[i][0], 2 * hs[i][1])
                v = (2 * hs[i + 1][0], 2 * hs[i + 1][1])
                m = ((u[0] + v[0]) // 2, (u[1] + v[1]) // 2)
                rail_edges.add(frozenset((u, m)))
                rail_edges.add(frozenset((m, v)))

    used_node_h, used_node_v, used_edge = {}, {}, {}

    iso_indices = [i for i, w in enumerate(wires) if w["type"] == "aislado"]
    iso_indices.sort(key=lambda i: (
        {"data": 0, "ctrl": 1, "dip": 2, "addr": 3, "bus": 4, "led": 5, "gnd": 6, "vcc": 7}.get(wires[i]["cls"], 8),
        wires[i]["net"],
        abs(wires[i]["a"][0] - wires[i]["b"][0]) + abs(wires[i]["a"][1] - wires[i]["b"][1]),
    ))

    for w in wires:
        if w["type"] != "aislado":
            w["path"] = [[float(w["a"][0]), float(w["a"][1])], [float(w["b"][0]), float(w["b"][1])]]

    DIRS = ((1, 0, 0), (-1, 0, 0), (0, 1, 1), (0, -1, 1))

    for idx in iso_indices:
        w = wires[idx]
        sx, sy = 2 * w["a"][0], 2 * w["a"][1]
        gx, gy = 2 * w["b"][0], 2 * w["b"][1]

        pq, best, parent = [], {}, {}
        for d in (0, 1):
            st = (sx, sy, d)
            best[st] = 0.0
            heapq.heappush(pq, (abs(gx - sx) + abs(gy - sy), 0.0, sx, sy, d))

        goal_st = None
        while pq:
            _, g_, x, y, ori = heapq.heappop(pq)
            if x == gx and y == gy:
                goal_st = (x, y, ori)
                break
            if g_ > best.get((x, y, ori), 1e18):
                continue
            for dx, dy, nori in DIRS:
                nx, ny = x + dx, y + dy
                if not (xmin <= nx <= xmax and ymin <= ny <= ymax):
                    continue
                step = 1.0
                if nori != ori and not (x == sx and y == sy):
                    step += 3.2
                is_goal = (nx == gx and ny == gy)
                if not is_goal:
                    if (nx, ny) in pad_nodes:
                        step += 28.0
                    elif nx % 2 == 0 and ny % 2 == 0:
                        step += 0.6
                    if nori == 0 and ny % 2 == 1:
                        step -= 0.12
                    if nori == 1 and nx % 2 == 1:
                        step -= 0.12
                e = frozenset(((x, y), (nx, ny)))
                if e in rail_edges:
                    step += 12.0
                uc = used_edge.get(e, 0)
                if uc:
                    step += 22.0 * uc
                if not is_goal:
                    if nori == 0:
                        if used_node_h.get((nx, ny), 0): step += 10.0
                        if used_node_v.get((nx, ny), 0): step += 2.2
                    else:
                        if used_node_v.get((nx, ny), 0): step += 10.0
                        if used_node_h.get((nx, ny), 0): step += 2.2

                ng = g_ + step
                nst = (nx, ny, nori)
                if ng < best.get(nst, 1e18):
                    best[nst] = ng
                    parent[nst] = (x, y, ori)
                    h_ = (abs(gx - nx) + abs(gy - ny)) * 0.88
                    heapq.heappush(pq, (ng + h_, ng, nx, ny, nori))

        raw = []
        cur = goal_st
        while cur is not None:
            raw.append((cur[0], cur[1]))
            cur = parent.get(cur)
        raw.reverse()

        for i in range(len(raw) - 1):
            u, v = raw[i], raw[i + 1]
            e = frozenset((u, v))
            used_edge[e] = used_edge.get(e, 0) + 1
            if u[1] == v[1]:
                used_node_h[v] = used_node_h.get(v, 0) + 1
            else:
                used_node_v[v] = used_node_v.get(v, 0) + 1

        simp = simplify_path([(x / 2.0, y / 2.0) for (x, y) in raw])
        w["path"] = [[c, r] for (c, r) in simp]
        dist = sum(abs(simp[i + 1][0] - simp[i][0]) + abs(simp[i + 1][1] - simp[i][1])
                   for i in range(len(simp) - 1))
        w["len_mm"] = round(dist * P + 6)


def check_body_overlaps(board):
    overlaps = []
    def bbox(c):
        xs = [board.xy(p["c"], p["r"])[0] for p in c["pads"]]
        ys = [board.xy(p["c"], p["r"])[1] for p in c["pads"]]
        cx, cy = (min(xs) + max(xs)) / 2.0, (min(ys) + max(ys)) / 2.0
        k = c["kind"]
        if k.startswith("DIP"): w, h = 10.0, (max(ys) - min(ys)) + 2.8
        elif k == "LED5": w, h = 5.6, 5.6
        elif k == "R762": w, h = (2.5, 6.3) if max(ys) - min(ys) > max(xs) - min(xs) else (6.3, 2.5)
        elif k == "C254": w, h = (1.8, 3.6) if max(ys) - min(ys) > max(xs) - min(xs) else (3.6, 1.8)
        elif k == "C508": w, h = (2.2, 5.2) if max(ys) - min(ys) > max(xs) - min(xs) else (5.2, 2.2)
        elif k == "SWDIP4": w, h = 12.3, 9.8
        elif k == "SWDIP8": w, h = 22.5, 9.8
        elif k.startswith("SIP"): w, h = (max(xs) - min(xs)) + 2.2, 2.5
        elif k == "PUSH6": w, h = 6.2, 6.2
        elif k == "SPDT3": w, h = 4.6, 8.6
        elif k == "EDGE14": w, h = 2.4, (max(ys) - min(ys)) + 1.8
        elif k.startswith("HDR"): w, h = (max(xs) - min(xs)) + 2.5, (max(ys) - min(ys)) + 2.5
        return (cx - w / 2.0, cy - h / 2.0, cx + w / 2.0, cy + h / 2.0)

    bs = [(c["ref"], bbox(c)) for c in board.comps]
    for i in range(len(bs)):
        for j in range(i + 1, len(bs)):
            r1, (x1, y1, x2, y2) = bs[i]
            r2, (a1, b1, a2, b2) = bs[j]
            ox = min(x2, a2) - max(x1, a1)
            oy = min(y2, b2) - max(y1, b1)
            if ox > 0.05 and oy > 0.05:
                overlaps.append(f"Colision fisica {r1} vs {r2} ({ox:.2f}x{oy:.2f} mm)")
    return overlaps


def solve_board(board):
    errs, warns = [], []
    pin_net = {}
    for net, pins in board.nets.items():
        for p in pins:
            if p in pin_net:
                errs.append("Pin %s duplicado en redes (%s, %s)" % (p, pin_net[p], net))
            pin_net[p] = net

    occ = {}
    pad_at = {}
    for comp in board.comps:
        for pd in comp["pads"]:
            key = "%s.%s" % (comp["ref"], pd["name"])
            net = pin_net.get(key)
            if net is None and key not in board.nc:
                warns.append("Pin sin asignar a red: " + key)
            h = (pd["c"], pd["r"])
            if not (board.cmin <= h[0] <= board.cols and 1 <= h[1] <= board.rows):
                errs.append("%s fuera de cuadricula %s" % (key, h))
            if h in occ:
                errs.append("Hueco %s ocupado doble (%s y %s)" % (h, occ[h][1], key))
            occ[h] = (net, key)
            pad_at.setdefault(key, []).append(h)

    rail_holes = {}
    for net, segs in board.rails.items():
        for a, b_ in segs:
            for h in seg_holes(a, b_):
                if h in occ and occ[h][0] != net:
                    errs.append("Riel %s pisa %s (red %s) en %s" % (net, occ[h][1], occ[h][0], h))
                if h in rail_holes and rail_holes[h] != net:
                    errs.append("Rieles %s/%s se cruzan en %s" % (net, rail_holes[h], h))
                rail_holes[h] = net
    for h, net in rail_holes.items():
        occ.setdefault(h, (net, "Riel " + net))

    def free_path(a, b_, net):
        if a[0] != b_[0] and a[1] != b_[1]:
            return False
        for h in seg_holes(a, b_):
            if h in (a, b_):
                continue
            if h in occ:
                return False
        return True

    def classify(a, b_, net):
        d = abs(a[0] - b_[0]) + abs(a[1] - b_[1])
        if d == 1:
            return "puente"
        if free_path(a, b_, net) and d <= 6:
            return "desnudo"
        return "aislado"

    def cost(a, b_, net):
        d = abs(a[0] - b_[0]) + abs(a[1] - b_[1])
        t = classify(a, b_, net)
        return d + (0 if t != "aislado" else 4) + (0.01 if a[0] != b_[0] and a[1] != b_[1] else 0)

    wires = []
    for net, pins in board.nets.items():
        pts = [(h, p) for p in pins for h in pad_at.get(p, [])]
        tree = [(h, "Riel " + net) for h, n in rail_holes.items() if n == net]
        if not tree:
            tree = [pts.pop(0)]
        intree = set(h for h, _ in tree)
        rest = [(h, p) for h, p in pts if h not in intree]
        while rest:
            best = None
            for i, (h, p) in enumerate(rest):
                for th, tl in tree:
                    cst = cost(th, h, net)
                    if best is None or cst < best[0]:
                        best = (cst, i, th, tl)
            _, i, th, tl = best
            h, p = rest.pop(i)
            if not any(tl2 == p for _, tl2 in tree):
                wires.append(dict(net=net, a=th, al=tl, b=h, bl=p, type=classify(th, h, net)))
            tree.append((h, p))

    for e in board.extra:
        wires.append(dict(
            net=e["net"], a=e["a"], al="Riel " + e["net"], b=e["b"],
            bl=occ.get(e["b"], (None, "Riel " + e["net"]))[1],
            type="potencia" if e["kind"] == "power" else e["kind"],
        ))

    order = {"potencia": 0, "puente": 1, "bridge": 1, "desnudo": 2, "aislado": 3}
    wires.sort(key=lambda w: (order[w["type"]], net_class(w["net"]), w["net"], w["a"]))
    for i, w in enumerate(wires, 1):
        w["id"] = "W%d" % i
        d = abs(w["a"][0] - w["b"][0]) + abs(w["a"][1] - w["b"][1])
        w["len_mm"] = round(d * P + (6 if w["type"] == "potencia" else 0))
        w["cls"] = net_class(w["net"])

    route_manhattan(board, wires, occ)
    errs.extend(check_body_overlaps(board))

    board.res = dict(errs=errs, warns=warns, wires=wires, occ=occ,
                     rail_holes=rail_holes, pin_net=pin_net)
    return board.res


# ============================================================================
#  MODULO MAR (7 x 9 cm — PY-7*9 CM: 31 cols x 25 filas + pads borde C=0)
#  Fidelidad exacta al montaje real (Cara componentes.jpeg / cara soldadura.jpeg)
#  y al esquematico del profesor (mar.sch): solo 1 capacitor C18 (100 nF),
#  sin C19/C20/RN1/R69 y sin headers J1/J2 separados.
# ============================================================================
def build_mar():
    b = Board("MAR", "MAR - Memory Address Register (7 x 9 cm, montaje real)",
              90.0, 70.0, 31, 25, cmin=0, board_style="fr4_green")
    A = b.add

    # Integrados reales con muesca hacia ABAJO (rot=180°), exactos a la foto fisica
    A("U34", "DIP16", "SN74LS173AN", 9, 12, 180,
      desc="Registro de direccion 4 bits (muesca abajo; C6..C9, F5..F12)")
    A("U33", "DIP16", "SN74LS157N", 18, 12, 180,
      desc="MUX direccion 4b RUN=U34 / PROG=SW5 (muesca abajo; C15..C18, F5..F12)")

    # Unico capacitor ceramico de 100 nF (0.1 uF) al principio de VCC hacia GND
    A("C18", "C254", "100nF", 3, 13, 90,
      desc="Desacoplo unico de entrada VCC -> GND (0.1 uF, junto a pad VCC y U34)")

    # DIP switch real de 4 posiciones KSPA04-NB (D3 D2 D1 D0, debajo de U33)
    A("SW5", "SWDIP4", "KSPA04-NB", 15, 19, 90,
      desc="DIP switch 4 pos. direccion manual D3..D0 (palancas abajo)")

    # 4 LEDs ROJOS de direccion (D3, D2, D1, D0) y sus 4 resistencias 220 Ohm (parte inferior izq.)
    for dref, rref, col, bit in [
        ("D44", "R59", 3, "D3 / A3"),
        ("D45", "R60", 6, "D2 / A2"),
        ("D46", "R61", 9, "D1 / A1"),
        ("D47", "R62", 12, "D0 / A0"),
    ]:
        A(rref, "R762", "220", col, 16, 270, desc="Limitadora 220 Ohm LED direccion " + bit)
        A(dref, "LED5", "ROJO", col, 23, 90, desc="LED rojo de direccion " + bit, color="#ff2b2b")

    # Indicadores de modo (Verde RUN, Rojo PROG), resistencias 1k e interruptor SPDT a la derecha
    A("D49", "LED5", "VERDE", 22, 14, 270, desc="LED indicador modo RUN (verde)", color="#22dd44")
    A("R64", "R762", "1k", 22, 17, 270, desc="Limitadora 1 kOhm LED RUN (verde)")
    A("D48", "LED5", "ROJO", 26, 14, 270, desc="LED indicador modo PROG (rojo)", color="#ff2b2b")
    A("R63", "R762", "1k", 24, 16, 270, desc="Limitadora 1 kOhm LED PROG (rojo)")
    A("SW6", "SPDT3", "SPDT PROG/RUN", 26, 19, 0,
      desc="Interruptor deslizable SPDT (arriba=Rojo PROG/pin S, centro=GND, abajo=Verde RUN)")

    # Interfaz directa en los pads del borde lateral de la baquelita (orden exacto de cara soldadura.jpeg)
    A("P_EXT", "EDGE14", "PADS BORDE", 0, 3, 0,
      desc="Interfaz directa en pads del borde lateral (borde derecho en cara soldadura)",
      labels=MAR_EDGE_LABELS)

    N = b.net
    # Alimentacion y masa
    N("GND",
      "P_EXT.1", "C18.2",
      "U34.8", "U34.1", "U34.2",
      "U33.8", "U33.15",
      "SW5.1", "SW5.2", "SW5.3", "SW5.4",
      "D44.1", "D45.1", "D46.1", "D47.1",
      "SW6.2")
    N("VCC", "P_EXT.9", "C18.1", "U34.16", "U33.16", "R63.2", "R64.2")

    # Control del registro U34 (74LS173) y bus de entrada BUS_0..BUS_3
    N("CLR", "P_EXT.2", "U34.15")
    N("CLK", "P_EXT.3", "U34.7")
    N("~MI", "P_EXT.4", "U34.9", "U34.10")
    N("BUS_0", "P_EXT.5", "U34.11")
    N("BUS_1", "P_EXT.6", "U34.12")
    N("BUS_2", "P_EXT.7", "U34.13")
    N("BUS_3", "P_EXT.8", "U34.14")

    # Salidas Q0..Q3 de U34 hacia entradas I1 de U33 (correspondencia exacta con mar.sch)
    N("Q_A3", "U34.3", "U33.3")
    N("Q_A2", "U34.4", "U33.6")
    N("Q_A1", "U34.5", "U33.13")
    N("Q_A0", "U34.6", "U33.10")

    # DIP switch SW5 (D3..D0 = pines superiores 8,7,6,5) hacia entradas I0 de U33
    N("SW_A3", "SW5.8", "U33.2")
    N("SW_A2", "SW5.7", "U33.5")
    N("SW_A1", "SW5.6", "U33.14")
    N("SW_A0", "SW5.5", "U33.11")

    # Salidas de direccion A3..A0 hacia pads de borde y resistencias/LEDs rojos D3..D0
    N("A3", "U33.4", "R59.1", "P_EXT.10")
    N("A2", "U33.7", "R60.1", "P_EXT.11")
    N("A1", "U33.12", "R61.1", "P_EXT.12")
    N("A0", "U33.9", "R62.1", "P_EXT.13")
    N("LED_A3", "R59.2", "D44.2")
    N("LED_A2", "R60.2", "D45.2")
    N("LED_A1", "R61.2", "D46.2")
    N("LED_A0", "R62.2", "D47.2")

    # Selector PROG / RUN y sus LEDs (SW6 arriba=PROG, centro=GND, abajo=RUN)
    N("PROG", "SW6.1", "D48.1", "U33.1", "P_EXT.14")
    N("RUN_K", "SW6.3", "D49.1")
    N("LED_PROG", "R63.1", "D48.2")
    N("LED_RUN", "R64.1", "D49.2")

    # Riel de masa en forma de C identico a cara soldadura.jpeg:
    # Superior (F3: C6..C30) + Lateral (C30: F3..F24) + Inferior (F24: C3..C30)
    b.rail("GND",
           ((6, 3), (30, 3)),
           ((30, 3), (30, 24)),
           ((3, 24), (30, 24)))
    b.notes = {
        "P_EXT": "Pads de borde lateral de la placa PY-7*9 CM (borde derecho visto desde cara soldadura)",
        "C18": "Unico capacitor ceramico 100 nF (0.1 uF) de entrada VCC -> GND, fiel a mar.sch y al montaje real",
        "U33/U34": "Ambos integrados montados sobre zocalos DIP-16 con la muesca orientada hacia abajo",
    }
    solve_board(b)
    return b


# ============================================================================
#  MODULO RAM (9 x 15 cm -> 51 cols x 30 filas, 74LS189 segun ram.sch)
#  - Eliminados C21..C27 y C28 (bulk).
#  - Unicamente DOS capacitores C16 y C17 (100 nF en paralelo) al principio de VCC -> GND.
#  - Conserva intacto C7 (10 nF / 0.01 uF) + R58 (1 kOhm) del detector de flanco RC.
# ============================================================================
def build_ram():
    b = Board("RAM", "RAM 16 x 8 Bytes (9 x 15 cm, 74LS189)",
              150.0, 90.0, 51, 30, cmin=1, board_style="bakelite")
    A = b.add

    # Columna 1 (X=7..10): MUX de escritura ~WE (justo debajo del pulsador WRITE)
    A("U32", "DIP16", "74LS157", 7, 10, desc="MUX ~WE (PROG=SW4 / RUN=U31)")

    # Columna 2 (X=14..17): MUX de datos 8 bits (U26 nibble alto arriba, U27 nibble bajo abajo)
    A("U26", "DIP16", "74LS157", 14, 10, desc="MUX datos bits 7..4 (BUS / DIP)")
    A("U27", "DIP16", "74LS157", 14, 21, desc="MUX datos bits 3..0 (BUS / DIP)")

    # Columna 3 (X=23..26): Memorias SRAM (U24 arriba y U25 abajo -> A0..A3 y ~WE bajan rectos)
    A("U24", "DIP16", "74LS189", 23, 10, desc="SRAM 16x4 nibble alto (bits 7..4)")
    A("U25", "DIP16", "74LS189", 23, 21, desc="SRAM 16x4 nibble bajo (bits 3..0)")

    # Columna 4 (X=32..35): Inversores de salida (pegados a U24/U25 y frente a U30)
    A("U28", "DIP14", "74LS04", 32, 10, desc="Inversores salida bits 7..4")
    A("U29", "DIP14", "74LS04", 32, 21, desc="Inversores salida bits 3..0")

    # Columna 5 (X=42..45): Transceptor de Bus arriba + NAND RI*CLK abajo (junto a J3)
    A("U30", "DIP20", "74LS245", 42, 10, desc="Transceptor triestado hacia Bus W")
    A("U31", "DIP14", "74LS00", 42, 21, desc="NAND RI * pulso de flanco CLK (junto a J3)")
    A("C7", "C508", "10nF", 49, 22, 180, desc="Detector de flanco RC en CLK (0.01 uF, funcional de ram.sch)")
    A("R58", "R762", "1k", 47, 23, 270, desc="Detector de flanco RC en CLK (R58 = 1 kOhm a GND)")

    # Zona frontal superior (sin RN2 ni R70: fiel al esquematico original ram.sch)
    A("SW4", "PUSH6", "WRITE", 3, 3, 0, desc="Pulsador de escritura manual")
    A("SW3", "SWDIP8", "DIP x8", 11, 6, 90, desc="Dato manual D7..D0 (MSB izquierda)")
    # Interfaz MAR -> RAM en el borde IZQUIERDO (opuesto a J3 en el borde derecho)
    A("J1", "HDR6", "DESDE MAR", 1, 19, 0, desc="Entrada MAR -> RAM en borde izquierdo (GND, PROG, A3..A0)",
      labels=["GND", "PROG", "A3", "A2", "A1", "A0"])
    for k in range(8):
        col = 28 + 3 * k
        A("D%d" % (36 + k), "LED5", "ROJO", col + 1, 3, 180, desc="LED dato D%d" % (7 - k), color="#ff2b2b")
        A("R%d" % (50 + k), "R762", "220 (sug. 1k)", col, 4, 270, desc="Limitadora LED D%d" % (7 - k))

    # Unicamente DOS capacitores de 100 nF (0.1 uF) en paralelo al principio de VCC -> GND (ram.sch)
    A("C16", "C254", "100nF", 47, 9, 90, desc="Desacoplo entrada 1 (0.1 uF en paralelo VCC -> GND, ram.sch)")
    A("C17", "C254", "100nF", 48, 9, 90, desc="Desacoplo entrada 2 (0.1 uF en paralelo VCC -> GND, ram.sch)")

    # Header derecho alineado 1 a 1 con U30 (74LS245) + RI/CLK pegados a U31/C7
    A("J3", "HDR16", "BUS W/CTRL", 50, 8, 0, desc="Al Bus W, control y alimentacion",
      labels=["GND", "VCC", "LLAVE", "~RO", "BUS_7", "BUS_6", "BUS_5", "BUS_4",
              "BUS_3", "BUS_2", "BUS_1", "BUS_0", "VCC", "RI", "CLK", "GND"])

    N = b.net
    gnd = [
        "U24.2", "U24.8", "U25.2", "U25.8", "U26.8", "U26.15", "U27.8", "U27.15",
        "U28.7", "U28.1", "U28.3", "U29.7", "U29.1", "U29.3", "U30.10",
        "U31.4", "U31.5", "U31.7", "U31.9", "U31.10", "U31.12", "U31.13",
        "U32.8", "U32.15", "U32.2", "U32.3", "U32.5", "U32.6", "U32.10", "U32.11",
        "SW4.1", "R58.2", "J1.1", "J3.1", "J3.16",
        "C16.2", "C17.2",
    ] + ["SW3.%d" % i for i in range(9, 17)] + ["D%d.1" % (36 + k) for k in range(8)]
    N("GND", *gnd)
    N("VCC", "U24.16", "U25.16", "U26.16", "U27.16", "U28.14", "U29.14",
      "U30.20", "U30.1", "U31.14", "U32.16", "J3.2", "J3.13",
      "C16.1", "C17.1")

    N("PROG", "J1.2", "U26.1", "U27.1", "U32.1")
    N("A0", "J1.6", "U24.1", "U25.1")
    N("A1", "J1.5", "U24.15", "U25.15")
    N("A2", "J1.4", "U24.14", "U25.14")
    N("A3", "J1.3", "U24.13", "U25.13")
    N("~WE", "U32.12", "U24.3", "U25.3")
    N("WR_BTN", "SW4.2", "U32.14")
    N("WE_RUN", "U31.3", "U32.13")
    N("RI", "J3.14", "U31.1")
    N("PULSO", "U31.2", "C7.2", "R58.1")
    N("CLK", "J3.15", "C7.1")
    N("~RO", "J3.4", "U30.19")

    bit_map = [
        (7, 1, "U26.14", "U26.13", "U26.12", "U24.4",  "U24.5",  "U28.13", "U28.12", "U30.2", "U30.18", 5,  0),
        (6, 2, "U26.2",  "U26.3",  "U26.4",  "U24.12", "U24.11", "U28.11", "U28.10", "U30.3", "U30.17", 6,  1),
        (5, 3, "U26.11", "U26.10", "U26.9",  "U24.6",  "U24.7",  "U28.9",  "U28.8",  "U30.4", "U30.16", 7,  2),
        (4, 4, "U26.5",  "U26.6",  "U26.7",  "U24.10", "U24.9",  "U28.5",  "U28.6",  "U30.5", "U30.15", 8,  3),
        (3, 5, "U27.14", "U27.13", "U27.12", "U25.4",  "U25.5",  "U29.13", "U29.12", "U30.6", "U30.14", 9,  4),
        (2, 6, "U27.2",  "U27.3",  "U27.4",  "U25.12", "U25.11", "U29.11", "U29.10", "U30.7", "U30.13", 10, 5),
        (1, 7, "U27.11", "U27.10", "U27.9",  "U25.6",  "U25.7",  "U29.9",  "U29.8",  "U30.8", "U30.12", 11, 6),
        (0, 8, "U27.5",  "U27.6",  "U27.7",  "U25.10", "U25.9",  "U29.5",  "U29.6",  "U30.9", "U30.11", 12, 7),
    ]
    for (bit, swp, mi0, mi1, mz, rd, rq, ii, io, a245, b245, j3p, lidx) in bit_map:
        N("SW_D%d" % bit, "SW3.%d" % swp, mi0)
        N("BUS_%d" % bit, "J3.%d" % j3p, b245, mi1)
        N("DI%d" % bit, mz, rd)
        N("~DO%d" % bit, rq, ii)
        N("DO%d" % bit, io, "R%d.2" % (50 + lidx), a245)
        N("LED_D%d" % bit, "R%d.1" % (50 + lidx), "D%d.2" % (36 + lidx))

    b.nc |= {"J3.3", "U28.2", "U28.4", "U29.2", "U29.4",
             "U31.6", "U31.8", "U31.11", "U32.4", "U32.7", "U32.9"}

    b.rail("GND",
           ((2, 1), (50, 1)), ((50, 1), (50, 8)), ((47, 8), (50, 8)),
           ((2, 1), (2, 29)),
           ((2, 18), (41, 18)), ((41, 18), (41, 19)),
           ((2, 29), (50, 29)), ((50, 23), (50, 29)))
    b.rail("VCC",
           ((4, 9), (50, 9)),
           ((4, 20), (50, 20)))
    b.extra = [
        dict(net="VCC", a=(4, 9), b=(4, 20), kind="power"),
        dict(net="VCC", a=(40, 9), b=(40, 20), kind="power"),
    ]
    b.notes = {
        "J3.3": "Pin retirado = llave mecanica antipolaridad",
        "C16/C17": "Dos capacitores de 100 nF (0.1 uF) en paralelo en la entrada VCC -> GND, fieles a ram.sch",
        "C7": "Capacitor funcional 10 nF (0.01 uF) del detector de flanco RC en CLK junto a R58 = 1 kOhm",
    }
    solve_board(b)
    return b

if __name__ == "__main__":
    for b in (build_mar(), build_ram()):
        r = b.res
        print(f"=== {b.name} ({b.cols}x{b.rows}, cmin={b.cmin}) ===")
        print(f"  Componentes: {len(b.comps)} | Conexiones: {len(r['wires'])}")
        print(f"  Errores: {len(r['errs'])} | Avisos: {len(r['warns'])}")
        for e in r["errs"]: print("  [ERROR]", e)
        for wv in r["warns"]: print("  [AVISO]", wv)
        cnt = {}
        for w in r["wires"]: cnt[w["type"]] = cnt.get(w["type"], 0) + 1
        print("  Desglose:", cnt, "| Cable aislado (mm):", sum(w["len_mm"] for w in r["wires"] if w["type"] == "aislado"))
